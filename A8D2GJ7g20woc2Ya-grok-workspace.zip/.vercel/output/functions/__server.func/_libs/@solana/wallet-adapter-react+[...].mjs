import { o as __toESM } from "../../_runtime.mjs";
import { u as require_react } from "../@floating-ui/react-dom+[...].mjs";
import { A as WalletSignInError, C as WalletDisconnectedError, D as WalletNotReadyError, E as WalletNotConnectedError, I as Transaction, M as WalletSignTransactionError, N as Connection, O as WalletPublicKeyError, P as PublicKey, R as VersionedTransaction, S as WalletConnectionError, T as WalletError, _ as isVersionedTransaction, a as createDefaultWalletNotFoundHandler, b as WalletAccountError, c as SOLANA_MAINNET_CHAIN, d as StandardDisconnect, f as StandardConnect, g as SolanaSignAndSendTransaction, h as SolanaSignIn, i as createDefaultAuthorizationResultCache, j as WalletSignMessageError, k as WalletSendTransactionError, l as SOLANA_TESTNET_CHAIN, m as SolanaSignMessage, n as SolanaMobileWalletAdapterWalletName, o as SOLANA_DEVNET_CHAIN, p as SolanaSignTransaction, r as createDefaultAddressSelector, s as SOLANA_LOCALNET_CHAIN, t as SolanaMobileWalletAdapter, u as StandardEvents, v as BaseWalletAdapter, w as WalletDisconnectionError, x as WalletConfigError, y as WalletReadyState } from "../@solana-mobile/wallet-adapter-mobile.mjs";
import { t as isWalletAdapterCompatibleStandardWallet } from "../solana__wallet-adapter-base.mjs";
//#region node_modules/@solana/wallet-adapter-react/lib/esm/useConnection.js
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var ConnectionContext = (0, import_react.createContext)({});
function useConnection() {
	return (0, import_react.useContext)(ConnectionContext);
}
//#endregion
//#region node_modules/@solana/wallet-adapter-react/lib/esm/ConnectionProvider.js
var ConnectionProvider = ({ children, endpoint, config = { commitment: "confirmed" } }) => {
	const connection = (0, import_react.useMemo)(() => new Connection(endpoint, config), [endpoint, config]);
	return import_react.createElement(ConnectionContext.Provider, { value: { connection } }, children);
};
//#endregion
//#region node_modules/@solana/wallet-adapter-react/lib/esm/errors.js
var WalletNotSelectedError = class extends WalletError {
	constructor() {
		super(...arguments);
		this.name = "WalletNotSelectedError";
	}
};
//#endregion
//#region node_modules/@solana/wallet-adapter-react/lib/esm/useWallet.js
var EMPTY_ARRAY = [];
var DEFAULT_CONTEXT = {
	autoConnect: false,
	connecting: false,
	connected: false,
	disconnecting: false,
	select() {
		logMissingProviderError("call", "select");
	},
	connect() {
		return Promise.reject(logMissingProviderError("call", "connect"));
	},
	disconnect() {
		return Promise.reject(logMissingProviderError("call", "disconnect"));
	},
	sendTransaction() {
		return Promise.reject(logMissingProviderError("call", "sendTransaction"));
	},
	signTransaction() {
		return Promise.reject(logMissingProviderError("call", "signTransaction"));
	},
	signAllTransactions() {
		return Promise.reject(logMissingProviderError("call", "signAllTransactions"));
	},
	signMessage() {
		return Promise.reject(logMissingProviderError("call", "signMessage"));
	},
	signIn() {
		return Promise.reject(logMissingProviderError("call", "signIn"));
	}
};
Object.defineProperty(DEFAULT_CONTEXT, "wallets", { get() {
	logMissingProviderError("read", "wallets");
	return EMPTY_ARRAY;
} });
Object.defineProperty(DEFAULT_CONTEXT, "wallet", { get() {
	logMissingProviderError("read", "wallet");
	return null;
} });
Object.defineProperty(DEFAULT_CONTEXT, "publicKey", { get() {
	logMissingProviderError("read", "publicKey");
	return null;
} });
function logMissingProviderError(action, property) {
	const error = /* @__PURE__ */ new Error(`You have tried to ${action} "${property}" on a WalletContext without providing one. Make sure to render a WalletProvider as an ancestor of the component that uses WalletContext.`);
	console.error(error);
	return error;
}
var WalletContext = (0, import_react.createContext)(DEFAULT_CONTEXT);
function useWallet() {
	return (0, import_react.useContext)(WalletContext);
}
//#endregion
//#region node_modules/@solana/wallet-adapter-react/lib/esm/useLocalStorage.js
function getLocalStorage() {
	try {
		if (typeof globalThis === "undefined") return null;
		return globalThis.localStorage ?? null;
	} catch {
		return null;
	}
}
function useLocalStorage(key, defaultState) {
	const state = (0, import_react.useState)(() => {
		const storage = getLocalStorage();
		if (!storage) return defaultState;
		try {
			const value = storage.getItem(key);
			if (value) return JSON.parse(value);
		} catch (error) {
			if (typeof window !== "undefined") console.error(error);
		}
		return defaultState;
	});
	const value = state[0];
	const isFirstRenderRef = (0, import_react.useRef)(true);
	(0, import_react.useEffect)(() => {
		if (isFirstRenderRef.current) {
			isFirstRenderRef.current = false;
			return;
		}
		try {
			const storage = getLocalStorage();
			if (!storage) return;
			if (value === null) storage.removeItem(key);
			else storage.setItem(key, JSON.stringify(value));
		} catch (error) {
			if (typeof window !== "undefined") console.error(error);
		}
	}, [value, key]);
	return state;
}
/**
* Efficiently compare {@link Indexed} arrays (e.g. `Array` and `Uint8Array`).
*
* @param a An array.
* @param b Another array.
*
* @return `true` if the arrays have the same length and elements, `false` otherwise.
*
* @group Util
*/
function arraysEqual(a, b) {
	if (a === b) return true;
	const length = a.length;
	if (length !== b.length) return false;
	for (let i = 0; i < length; i++) if (a[i] !== b[i]) return false;
	return true;
}
//#endregion
//#region node_modules/@solana/wallet-standard-util/lib/esm/commitment.js
/**
* TODO: docs
*/
function getCommitment(commitment) {
	switch (commitment) {
		case "processed":
		case "confirmed":
		case "finalized":
		case void 0: return commitment;
		case "recent": return "processed";
		case "single":
		case "singleGossip": return "confirmed";
		case "max":
		case "root": return "finalized";
		default: return;
	}
}
/**
* TODO: docs
*/
function getChainForEndpoint(endpoint) {
	if (endpoint.includes("https://api.mainnet-beta.solana.com")) return SOLANA_MAINNET_CHAIN;
	if (/\bdevnet\b/i.test(endpoint)) return SOLANA_DEVNET_CHAIN;
	if (/\btestnet\b/i.test(endpoint)) return SOLANA_TESTNET_CHAIN;
	if (/\blocalhost\b/i.test(endpoint) || /\b127\.0\.0\.1\b/.test(endpoint)) return SOLANA_LOCALNET_CHAIN;
	return SOLANA_MAINNET_CHAIN;
}
//#endregion
//#region node_modules/@wallet-standard/app/lib/esm/wallets.js
var __classPrivateFieldGet$1 = function(receiver, state, kind, f) {
	if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a getter");
	if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
	return kind === "m" ? f : kind === "a" ? f.call(receiver) : f ? f.value : state.get(receiver);
};
var __classPrivateFieldSet$1 = function(receiver, state, value, kind, f) {
	if (kind === "m") throw new TypeError("Private method is not writable");
	if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a setter");
	if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot write private member to an object whose class did not declare it");
	return kind === "a" ? f.call(receiver, value) : f ? f.value = value : state.set(receiver, value), value;
};
var _AppReadyEvent_detail;
var wallets = void 0;
var registeredWalletsSet = /* @__PURE__ */ new Set();
function addRegisteredWallet(wallet) {
	cachedWalletsArray = void 0;
	registeredWalletsSet.add(wallet);
}
function removeRegisteredWallet(wallet) {
	cachedWalletsArray = void 0;
	registeredWalletsSet.delete(wallet);
}
var listeners = {};
/**
* Get an API for {@link Wallets.get | getting}, {@link Wallets.on | listening for}, and
* {@link Wallets.register | registering} {@link "@wallet-standard/base".Wallet | Wallets}.
*
* When called for the first time --
*
* This dispatches a {@link "@wallet-standard/base".WindowAppReadyEvent} to notify each Wallet that the app is ready
* to register it.
*
* This also adds a listener for {@link "@wallet-standard/base".WindowRegisterWalletEvent} to listen for a notification
* from each Wallet that the Wallet is ready to be registered by the app.
*
* This combination of event dispatch and listener guarantees that each Wallet will be registered synchronously as soon
* as the app is ready whether the app loads before or after each Wallet.
*
* @return API for getting, listening for, and registering Wallets.
*
* @group App
*/
function getWallets() {
	if (wallets) return wallets;
	wallets = Object.freeze({
		register,
		get,
		on
	});
	if (typeof window === "undefined") return wallets;
	const api = Object.freeze({ register });
	try {
		window.addEventListener("wallet-standard:register-wallet", ({ detail: callback }) => callback(api));
	} catch (error) {
		console.error("wallet-standard:register-wallet event listener could not be added\n", error);
	}
	try {
		window.dispatchEvent(new AppReadyEvent(api));
	} catch (error) {
		console.error("wallet-standard:app-ready event could not be dispatched\n", error);
	}
	return wallets;
}
function register(...wallets) {
	wallets = wallets.filter((wallet) => !registeredWalletsSet.has(wallet));
	if (!wallets.length) return () => {};
	wallets.forEach((wallet) => addRegisteredWallet(wallet));
	listeners["register"]?.forEach((listener) => guard(() => listener(...wallets)));
	return function unregister() {
		wallets.forEach((wallet) => removeRegisteredWallet(wallet));
		listeners["unregister"]?.forEach((listener) => guard(() => listener(...wallets)));
	};
}
var cachedWalletsArray;
function get() {
	if (!cachedWalletsArray) cachedWalletsArray = [...registeredWalletsSet];
	return cachedWalletsArray;
}
function on(event, listener) {
	listeners[event]?.push(listener) || (listeners[event] = [listener]);
	return function off() {
		listeners[event] = listeners[event]?.filter((existingListener) => listener !== existingListener);
	};
}
function guard(callback) {
	try {
		callback();
	} catch (error) {
		console.error(error);
	}
}
var AppReadyEvent = class extends Event {
	get detail() {
		return __classPrivateFieldGet$1(this, _AppReadyEvent_detail, "f");
	}
	get type() {
		return "wallet-standard:app-ready";
	}
	constructor(api) {
		super("wallet-standard:app-ready", {
			bubbles: false,
			cancelable: false,
			composed: false
		});
		_AppReadyEvent_detail.set(this, void 0);
		__classPrivateFieldSet$1(this, _AppReadyEvent_detail, api, "f");
	}
	/** @deprecated */
	preventDefault() {
		throw new Error("preventDefault cannot be called");
	}
	/** @deprecated */
	stopImmediatePropagation() {
		throw new Error("stopImmediatePropagation cannot be called");
	}
	/** @deprecated */
	stopPropagation() {
		throw new Error("stopPropagation cannot be called");
	}
};
_AppReadyEvent_detail = /* @__PURE__ */ new WeakMap();
/**
* @deprecated Use {@link getWallets} instead.
*
* @group Deprecated
*/
function DEPRECATED_getWallets() {
	if (wallets) return wallets;
	wallets = getWallets();
	if (typeof window === "undefined") return wallets;
	const callbacks = window.navigator.wallets || [];
	if (!Array.isArray(callbacks)) {
		console.error("window.navigator.wallets is not an array");
		return wallets;
	}
	const { register } = wallets;
	const push = (...callbacks) => callbacks.forEach((callback) => guard(() => callback({ register })));
	try {
		Object.defineProperty(window.navigator, "wallets", { value: Object.freeze({ push }) });
	} catch (error) {
		console.error("window.navigator.wallets could not be set");
		return wallets;
	}
	push(...callbacks);
	return wallets;
}
//#endregion
//#region node_modules/base-x/src/esm/index.js
function base(ALPHABET) {
	if (ALPHABET.length >= 255) throw new TypeError("Alphabet too long");
	const BASE_MAP = /* @__PURE__ */ new Uint8Array(256);
	for (let j = 0; j < BASE_MAP.length; j++) BASE_MAP[j] = 255;
	for (let i = 0; i < ALPHABET.length; i++) {
		const x = ALPHABET.charAt(i);
		const xc = x.charCodeAt(0);
		if (BASE_MAP[xc] !== 255) throw new TypeError(x + " is ambiguous");
		BASE_MAP[xc] = i;
	}
	const BASE = ALPHABET.length;
	const LEADER = ALPHABET.charAt(0);
	const FACTOR = Math.log(BASE) / Math.log(256);
	const iFACTOR = Math.log(256) / Math.log(BASE);
	function encode(source) {
		if (source instanceof Uint8Array) {} else if (ArrayBuffer.isView(source)) source = new Uint8Array(source.buffer, source.byteOffset, source.byteLength);
		else if (Array.isArray(source)) source = Uint8Array.from(source);
		if (!(source instanceof Uint8Array)) throw new TypeError("Expected Uint8Array");
		if (source.length === 0) return "";
		let zeroes = 0;
		let length = 0;
		let pbegin = 0;
		const pend = source.length;
		while (pbegin !== pend && source[pbegin] === 0) {
			pbegin++;
			zeroes++;
		}
		const size = (pend - pbegin) * iFACTOR + 1 >>> 0;
		const b58 = new Uint8Array(size);
		while (pbegin !== pend) {
			let carry = source[pbegin];
			let i = 0;
			for (let it1 = size - 1; (carry !== 0 || i < length) && it1 !== -1; it1--, i++) {
				carry += 256 * b58[it1] >>> 0;
				b58[it1] = carry % BASE >>> 0;
				carry = carry / BASE >>> 0;
			}
			if (carry !== 0) throw new Error("Non-zero carry");
			length = i;
			pbegin++;
		}
		let it2 = size - length;
		while (it2 !== size && b58[it2] === 0) it2++;
		let str = LEADER.repeat(zeroes);
		for (; it2 < size; ++it2) str += ALPHABET.charAt(b58[it2]);
		return str;
	}
	function decodeUnsafe(source) {
		if (typeof source !== "string") throw new TypeError("Expected String");
		if (source.length === 0) return /* @__PURE__ */ new Uint8Array();
		let psz = 0;
		let zeroes = 0;
		let length = 0;
		while (source[psz] === LEADER) {
			zeroes++;
			psz++;
		}
		const size = (source.length - psz) * FACTOR + 1 >>> 0;
		const b256 = new Uint8Array(size);
		while (psz < source.length) {
			const charCode = source.charCodeAt(psz);
			if (charCode > 255) return;
			let carry = BASE_MAP[charCode];
			if (carry === 255) return;
			let i = 0;
			for (let it3 = size - 1; (carry !== 0 || i < length) && it3 !== -1; it3--, i++) {
				carry += BASE * b256[it3] >>> 0;
				b256[it3] = carry % 256 >>> 0;
				carry = carry / 256 >>> 0;
			}
			if (carry !== 0) throw new Error("Non-zero carry");
			length = i;
			psz++;
		}
		let it4 = size - length;
		while (it4 !== size && b256[it4] === 0) it4++;
		const vch = new Uint8Array(zeroes + (size - it4));
		let j = zeroes;
		while (it4 !== size) vch[j++] = b256[it4++];
		return vch;
	}
	function decode(string) {
		const buffer = decodeUnsafe(string);
		if (buffer) return buffer;
		throw new Error("Non-base" + BASE + " character");
	}
	return {
		encode,
		decodeUnsafe,
		decode
	};
}
var esm_default = base("123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz");
//#endregion
//#region node_modules/@solana/wallet-standard-wallet-adapter-base/lib/esm/adapter.js
var __classPrivateFieldGet = function(receiver, state, kind, f) {
	if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a getter");
	if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
	return kind === "m" ? f : kind === "a" ? f.call(receiver) : f ? f.value : state.get(receiver);
};
var __classPrivateFieldSet = function(receiver, state, value, kind, f) {
	if (kind === "m") throw new TypeError("Private method is not writable");
	if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a setter");
	if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot write private member to an object whose class did not declare it");
	return kind === "a" ? f.call(receiver, value) : f ? f.value = value : state.set(receiver, value), value;
};
var _StandardWalletAdapter_instances;
var _StandardWalletAdapter_account;
var _StandardWalletAdapter_publicKey;
var _StandardWalletAdapter_connecting;
var _StandardWalletAdapter_disconnecting;
var _StandardWalletAdapter_off;
var _StandardWalletAdapter_supportedTransactionVersions;
var _StandardWalletAdapter_wallet;
var _StandardWalletAdapter_readyState;
var _StandardWalletAdapter_connect;
var _StandardWalletAdapter_connected;
var _StandardWalletAdapter_disconnected;
var _StandardWalletAdapter_reset;
var _StandardWalletAdapter_changed;
var _StandardWalletAdapter_signTransaction;
var _StandardWalletAdapter_signAllTransactions;
var _StandardWalletAdapter_signMessage;
var _StandardWalletAdapter_signIn;
/** TODO: docs */
var StandardWalletAdapter = class extends BaseWalletAdapter {
	get name() {
		return __classPrivateFieldGet(this, _StandardWalletAdapter_wallet, "f").name;
	}
	get url() {
		return "https://github.com/solana-labs/wallet-standard";
	}
	get icon() {
		return __classPrivateFieldGet(this, _StandardWalletAdapter_wallet, "f").icon;
	}
	get readyState() {
		return __classPrivateFieldGet(this, _StandardWalletAdapter_readyState, "f");
	}
	get publicKey() {
		return __classPrivateFieldGet(this, _StandardWalletAdapter_publicKey, "f");
	}
	get connecting() {
		return __classPrivateFieldGet(this, _StandardWalletAdapter_connecting, "f");
	}
	get supportedTransactionVersions() {
		return __classPrivateFieldGet(this, _StandardWalletAdapter_supportedTransactionVersions, "f");
	}
	get wallet() {
		return __classPrivateFieldGet(this, _StandardWalletAdapter_wallet, "f");
	}
	get standard() {
		return true;
	}
	constructor({ wallet }) {
		super();
		_StandardWalletAdapter_instances.add(this);
		_StandardWalletAdapter_account.set(this, void 0);
		_StandardWalletAdapter_publicKey.set(this, void 0);
		_StandardWalletAdapter_connecting.set(this, void 0);
		_StandardWalletAdapter_disconnecting.set(this, void 0);
		_StandardWalletAdapter_off.set(this, void 0);
		_StandardWalletAdapter_supportedTransactionVersions.set(this, void 0);
		_StandardWalletAdapter_wallet.set(this, void 0);
		_StandardWalletAdapter_readyState.set(this, typeof window === "undefined" || typeof document === "undefined" ? WalletReadyState.Unsupported : WalletReadyState.Installed);
		_StandardWalletAdapter_changed.set(this, (properties) => {
			if ("accounts" in properties) {
				const account = __classPrivateFieldGet(this, _StandardWalletAdapter_wallet, "f").accounts[0];
				if (__classPrivateFieldGet(this, _StandardWalletAdapter_account, "f") && !__classPrivateFieldGet(this, _StandardWalletAdapter_disconnecting, "f") && account !== __classPrivateFieldGet(this, _StandardWalletAdapter_account, "f")) {
					if (account) __classPrivateFieldGet(this, _StandardWalletAdapter_instances, "m", _StandardWalletAdapter_connected).call(this, account);
					else {
						this.emit("error", new WalletDisconnectedError());
						__classPrivateFieldGet(this, _StandardWalletAdapter_instances, "m", _StandardWalletAdapter_disconnected).call(this);
					}
				}
			}
			if ("features" in properties) __classPrivateFieldGet(this, _StandardWalletAdapter_instances, "m", _StandardWalletAdapter_reset).call(this);
		});
		__classPrivateFieldSet(this, _StandardWalletAdapter_wallet, wallet, "f");
		__classPrivateFieldSet(this, _StandardWalletAdapter_account, null, "f");
		__classPrivateFieldSet(this, _StandardWalletAdapter_publicKey, null, "f");
		__classPrivateFieldSet(this, _StandardWalletAdapter_connecting, false, "f");
		__classPrivateFieldSet(this, _StandardWalletAdapter_disconnecting, false, "f");
		__classPrivateFieldSet(this, _StandardWalletAdapter_off, __classPrivateFieldGet(this, _StandardWalletAdapter_wallet, "f").features[StandardEvents].on("change", __classPrivateFieldGet(this, _StandardWalletAdapter_changed, "f")), "f");
		__classPrivateFieldGet(this, _StandardWalletAdapter_instances, "m", _StandardWalletAdapter_reset).call(this);
	}
	destroy() {
		__classPrivateFieldSet(this, _StandardWalletAdapter_account, null, "f");
		__classPrivateFieldSet(this, _StandardWalletAdapter_publicKey, null, "f");
		__classPrivateFieldSet(this, _StandardWalletAdapter_connecting, false, "f");
		__classPrivateFieldSet(this, _StandardWalletAdapter_disconnecting, false, "f");
		const off = __classPrivateFieldGet(this, _StandardWalletAdapter_off, "f");
		if (off) {
			__classPrivateFieldSet(this, _StandardWalletAdapter_off, null, "f");
			off();
		}
	}
	async autoConnect() {
		return __classPrivateFieldGet(this, _StandardWalletAdapter_instances, "m", _StandardWalletAdapter_connect).call(this, { silent: true });
	}
	async connect() {
		return __classPrivateFieldGet(this, _StandardWalletAdapter_instances, "m", _StandardWalletAdapter_connect).call(this);
	}
	async disconnect() {
		if ("standard:disconnect" in __classPrivateFieldGet(this, _StandardWalletAdapter_wallet, "f").features) try {
			__classPrivateFieldSet(this, _StandardWalletAdapter_disconnecting, true, "f");
			await __classPrivateFieldGet(this, _StandardWalletAdapter_wallet, "f").features[StandardDisconnect].disconnect();
		} catch (error) {
			this.emit("error", new WalletDisconnectionError(error?.message, error));
		} finally {
			__classPrivateFieldSet(this, _StandardWalletAdapter_disconnecting, false, "f");
		}
		__classPrivateFieldGet(this, _StandardWalletAdapter_instances, "m", _StandardWalletAdapter_disconnected).call(this);
	}
	async sendTransaction(transaction, connection, options = {}) {
		try {
			const account = __classPrivateFieldGet(this, _StandardWalletAdapter_account, "f");
			if (!account) throw new WalletNotConnectedError();
			let feature;
			if ("solana:signAndSendTransaction" in __classPrivateFieldGet(this, _StandardWalletAdapter_wallet, "f").features) {
				if (account.features.includes("solana:signAndSendTransaction")) feature = SolanaSignAndSendTransaction;
				else if ("solana:signTransaction" in __classPrivateFieldGet(this, _StandardWalletAdapter_wallet, "f").features && account.features.includes("solana:signTransaction")) feature = SolanaSignTransaction;
				else throw new WalletAccountError();
			} else if ("solana:signTransaction" in __classPrivateFieldGet(this, _StandardWalletAdapter_wallet, "f").features) {
				if (!account.features.includes("solana:signTransaction")) throw new WalletAccountError();
				feature = SolanaSignTransaction;
			} else throw new WalletConfigError();
			const chain = getChainForEndpoint(connection.rpcEndpoint);
			if (!account.chains.includes(chain)) throw new WalletSendTransactionError();
			try {
				const { signers, ...sendOptions } = options;
				let serializedTransaction;
				if (isVersionedTransaction(transaction)) {
					signers?.length && transaction.sign(signers);
					serializedTransaction = transaction.serialize();
				} else {
					transaction = await this.prepareTransaction(transaction, connection, sendOptions);
					signers?.length && transaction.partialSign(...signers);
					serializedTransaction = new Uint8Array(transaction.serialize({
						requireAllSignatures: false,
						verifySignatures: false
					}));
				}
				if (feature === "solana:signAndSendTransaction") {
					const [output] = await __classPrivateFieldGet(this, _StandardWalletAdapter_wallet, "f").features[SolanaSignAndSendTransaction].signAndSendTransaction({
						account,
						chain,
						transaction: serializedTransaction,
						options: {
							preflightCommitment: getCommitment(sendOptions.preflightCommitment || connection.commitment),
							skipPreflight: sendOptions.skipPreflight,
							maxRetries: sendOptions.maxRetries,
							minContextSlot: sendOptions.minContextSlot
						}
					});
					return esm_default.encode(output.signature);
				} else {
					const [output] = await __classPrivateFieldGet(this, _StandardWalletAdapter_wallet, "f").features[SolanaSignTransaction].signTransaction({
						account,
						chain,
						transaction: serializedTransaction,
						options: {
							preflightCommitment: getCommitment(sendOptions.preflightCommitment || connection.commitment),
							minContextSlot: sendOptions.minContextSlot
						}
					});
					return await connection.sendRawTransaction(output.signedTransaction, {
						...sendOptions,
						preflightCommitment: getCommitment(sendOptions.preflightCommitment || connection.commitment)
					});
				}
			} catch (error) {
				if (error instanceof WalletError) throw error;
				throw new WalletSendTransactionError(error?.message, error);
			}
		} catch (error) {
			this.emit("error", error);
			throw error;
		}
	}
};
_StandardWalletAdapter_account = /* @__PURE__ */ new WeakMap(), _StandardWalletAdapter_publicKey = /* @__PURE__ */ new WeakMap(), _StandardWalletAdapter_connecting = /* @__PURE__ */ new WeakMap(), _StandardWalletAdapter_disconnecting = /* @__PURE__ */ new WeakMap(), _StandardWalletAdapter_off = /* @__PURE__ */ new WeakMap(), _StandardWalletAdapter_supportedTransactionVersions = /* @__PURE__ */ new WeakMap(), _StandardWalletAdapter_wallet = /* @__PURE__ */ new WeakMap(), _StandardWalletAdapter_readyState = /* @__PURE__ */ new WeakMap(), _StandardWalletAdapter_changed = /* @__PURE__ */ new WeakMap(), _StandardWalletAdapter_instances = /* @__PURE__ */ new WeakSet(), _StandardWalletAdapter_connect = async function _StandardWalletAdapter_connect(input) {
	try {
		if (this.connected || this.connecting) return;
		if (__classPrivateFieldGet(this, _StandardWalletAdapter_readyState, "f") !== WalletReadyState.Installed) throw new WalletNotReadyError();
		__classPrivateFieldSet(this, _StandardWalletAdapter_connecting, true, "f");
		if (!__classPrivateFieldGet(this, _StandardWalletAdapter_wallet, "f").accounts.length) try {
			await __classPrivateFieldGet(this, _StandardWalletAdapter_wallet, "f").features[StandardConnect].connect(input);
		} catch (error) {
			throw new WalletConnectionError(error?.message, error);
		}
		const account = __classPrivateFieldGet(this, _StandardWalletAdapter_wallet, "f").accounts[0];
		if (!account) throw new WalletAccountError();
		__classPrivateFieldGet(this, _StandardWalletAdapter_instances, "m", _StandardWalletAdapter_connected).call(this, account);
	} catch (error) {
		this.emit("error", error);
		throw error;
	} finally {
		__classPrivateFieldSet(this, _StandardWalletAdapter_connecting, false, "f");
	}
}, _StandardWalletAdapter_connected = function _StandardWalletAdapter_connected(account) {
	let publicKey;
	try {
		publicKey = new PublicKey(account.address);
	} catch (error) {
		throw new WalletPublicKeyError(error?.message, error);
	}
	__classPrivateFieldSet(this, _StandardWalletAdapter_account, account, "f");
	__classPrivateFieldSet(this, _StandardWalletAdapter_publicKey, publicKey, "f");
	__classPrivateFieldGet(this, _StandardWalletAdapter_instances, "m", _StandardWalletAdapter_reset).call(this);
	this.emit("connect", publicKey);
}, _StandardWalletAdapter_disconnected = function _StandardWalletAdapter_disconnected() {
	__classPrivateFieldSet(this, _StandardWalletAdapter_account, null, "f");
	__classPrivateFieldSet(this, _StandardWalletAdapter_publicKey, null, "f");
	__classPrivateFieldGet(this, _StandardWalletAdapter_instances, "m", _StandardWalletAdapter_reset).call(this);
	this.emit("disconnect");
}, _StandardWalletAdapter_reset = function _StandardWalletAdapter_reset() {
	const supportedTransactionVersions = "solana:signAndSendTransaction" in __classPrivateFieldGet(this, _StandardWalletAdapter_wallet, "f").features ? __classPrivateFieldGet(this, _StandardWalletAdapter_wallet, "f").features[SolanaSignAndSendTransaction].supportedTransactionVersions : __classPrivateFieldGet(this, _StandardWalletAdapter_wallet, "f").features[SolanaSignTransaction].supportedTransactionVersions;
	__classPrivateFieldSet(this, _StandardWalletAdapter_supportedTransactionVersions, arraysEqual(supportedTransactionVersions, ["legacy"]) ? null : new Set(supportedTransactionVersions), "f");
	if ("solana:signTransaction" in __classPrivateFieldGet(this, _StandardWalletAdapter_wallet, "f").features && __classPrivateFieldGet(this, _StandardWalletAdapter_account, "f")?.features.includes("solana:signTransaction")) {
		this.signTransaction = __classPrivateFieldGet(this, _StandardWalletAdapter_instances, "m", _StandardWalletAdapter_signTransaction);
		this.signAllTransactions = __classPrivateFieldGet(this, _StandardWalletAdapter_instances, "m", _StandardWalletAdapter_signAllTransactions);
	} else {
		delete this.signTransaction;
		delete this.signAllTransactions;
	}
	if ("solana:signMessage" in __classPrivateFieldGet(this, _StandardWalletAdapter_wallet, "f").features && __classPrivateFieldGet(this, _StandardWalletAdapter_account, "f")?.features.includes("solana:signMessage")) this.signMessage = __classPrivateFieldGet(this, _StandardWalletAdapter_instances, "m", _StandardWalletAdapter_signMessage);
	else delete this.signMessage;
	if ("solana:signIn" in __classPrivateFieldGet(this, _StandardWalletAdapter_wallet, "f").features) this.signIn = __classPrivateFieldGet(this, _StandardWalletAdapter_instances, "m", _StandardWalletAdapter_signIn);
	else delete this.signIn;
}, _StandardWalletAdapter_signTransaction = async function _StandardWalletAdapter_signTransaction(transaction) {
	try {
		const account = __classPrivateFieldGet(this, _StandardWalletAdapter_account, "f");
		if (!account) throw new WalletNotConnectedError();
		if (!("solana:signTransaction" in __classPrivateFieldGet(this, _StandardWalletAdapter_wallet, "f").features)) throw new WalletConfigError();
		if (!account.features.includes("solana:signTransaction")) throw new WalletAccountError();
		try {
			const serializedTransaction = (await __classPrivateFieldGet(this, _StandardWalletAdapter_wallet, "f").features[SolanaSignTransaction].signTransaction({
				account,
				transaction: isVersionedTransaction(transaction) ? transaction.serialize() : new Uint8Array(transaction.serialize({
					requireAllSignatures: false,
					verifySignatures: false
				}))
			}))[0].signedTransaction;
			return isVersionedTransaction(transaction) ? VersionedTransaction.deserialize(serializedTransaction) : Transaction.from(serializedTransaction);
		} catch (error) {
			if (error instanceof WalletError) throw error;
			throw new WalletSignTransactionError(error?.message, error);
		}
	} catch (error) {
		this.emit("error", error);
		throw error;
	}
}, _StandardWalletAdapter_signAllTransactions = async function _StandardWalletAdapter_signAllTransactions(transactions) {
	try {
		const account = __classPrivateFieldGet(this, _StandardWalletAdapter_account, "f");
		if (!account) throw new WalletNotConnectedError();
		if (!("solana:signTransaction" in __classPrivateFieldGet(this, _StandardWalletAdapter_wallet, "f").features)) throw new WalletConfigError();
		if (!account.features.includes("solana:signTransaction")) throw new WalletAccountError();
		try {
			const signedTransactions = await __classPrivateFieldGet(this, _StandardWalletAdapter_wallet, "f").features[SolanaSignTransaction].signTransaction(...transactions.map((transaction) => ({
				account,
				transaction: isVersionedTransaction(transaction) ? transaction.serialize() : new Uint8Array(transaction.serialize({
					requireAllSignatures: false,
					verifySignatures: false
				}))
			})));
			return transactions.map((transaction, index) => {
				const signedTransaction = signedTransactions[index].signedTransaction;
				return isVersionedTransaction(transaction) ? VersionedTransaction.deserialize(signedTransaction) : Transaction.from(signedTransaction);
			});
		} catch (error) {
			throw new WalletSignTransactionError(error?.message, error);
		}
	} catch (error) {
		this.emit("error", error);
		throw error;
	}
}, _StandardWalletAdapter_signMessage = async function _StandardWalletAdapter_signMessage(message) {
	try {
		const account = __classPrivateFieldGet(this, _StandardWalletAdapter_account, "f");
		if (!account) throw new WalletNotConnectedError();
		if (!("solana:signMessage" in __classPrivateFieldGet(this, _StandardWalletAdapter_wallet, "f").features)) throw new WalletConfigError();
		if (!account.features.includes("solana:signMessage")) throw new WalletAccountError();
		try {
			return (await __classPrivateFieldGet(this, _StandardWalletAdapter_wallet, "f").features[SolanaSignMessage].signMessage({
				account,
				message
			}))[0].signature;
		} catch (error) {
			throw new WalletSignMessageError(error?.message, error);
		}
	} catch (error) {
		this.emit("error", error);
		throw error;
	}
}, _StandardWalletAdapter_signIn = async function _StandardWalletAdapter_signIn(input = {}) {
	try {
		if (!("solana:signIn" in __classPrivateFieldGet(this, _StandardWalletAdapter_wallet, "f").features)) throw new WalletConfigError();
		let output;
		try {
			[output] = await __classPrivateFieldGet(this, _StandardWalletAdapter_wallet, "f").features[SolanaSignIn].signIn(input);
		} catch (error) {
			throw new WalletSignInError(error?.message, error);
		}
		if (!output) throw new WalletSignInError();
		__classPrivateFieldGet(this, _StandardWalletAdapter_instances, "m", _StandardWalletAdapter_connected).call(this, output.account);
		return output;
	} catch (error) {
		this.emit("error", error);
		throw error;
	}
};
//#endregion
//#region node_modules/@solana/wallet-standard-wallet-adapter-base/lib/esm/types.js
/**
* @deprecated Use `isWalletAdapterCompatibleStandardWallet` from `@solana/wallet-adapter-base` instead.
*
* @group Deprecated
*/
var isWalletAdapterCompatibleWallet = isWalletAdapterCompatibleStandardWallet;
//#endregion
//#region node_modules/@solana/wallet-standard-wallet-adapter-react/lib/esm/useStandardWalletAdapters.js
function useStandardWalletAdapters(adapters) {
	const warnings = useConstant(() => /* @__PURE__ */ new Set());
	const { get, on } = useConstant(() => DEPRECATED_getWallets());
	const [standardAdapters, setStandardAdapters] = (0, import_react.useState)(() => wrapWalletsWithAdapters(get()));
	(0, import_react.useEffect)(() => {
		const listeners = [on("register", (...wallets) => setStandardAdapters((standardAdapters) => [...standardAdapters, ...wrapWalletsWithAdapters(wallets)])), on("unregister", (...wallets) => setStandardAdapters((standardAdapters) => standardAdapters.filter((standardAdapter) => !wallets.includes(standardAdapter.wallet))))];
		return () => listeners.forEach((off) => off());
	}, [on]);
	const prevStandardAdapters = usePrevious(standardAdapters);
	(0, import_react.useEffect)(() => {
		if (!prevStandardAdapters) return;
		const currentAdapters = new Set(standardAdapters);
		new Set(prevStandardAdapters.filter((previousAdapter) => !currentAdapters.has(previousAdapter))).forEach((adapter) => adapter.destroy());
	}, [prevStandardAdapters, standardAdapters]);
	(0, import_react.useEffect)(() => () => standardAdapters.forEach((adapter) => adapter.destroy()), []);
	return (0, import_react.useMemo)(() => [...standardAdapters, ...adapters.filter(({ name }) => {
		if (standardAdapters.some((standardAdapter) => standardAdapter.name === name)) {
			if (!warnings.has(name)) {
				warnings.add(name);
				console.warn(`${name} was registered as a Standard Wallet. The Wallet Adapter for ${name} can be removed from your app.`);
			}
			return false;
		}
		return true;
	})], [
		standardAdapters,
		adapters,
		warnings
	]);
}
function useConstant(fn) {
	const ref = (0, import_react.useRef)(void 0);
	if (ref.current === void 0) ref.current = { value: fn() };
	return ref.current.value;
}
function usePrevious(state) {
	const ref = (0, import_react.useRef)(void 0);
	(0, import_react.useEffect)(() => {
		ref.current = state;
	});
	return ref.current;
}
function wrapWalletsWithAdapters(wallets) {
	return wallets.filter(isWalletAdapterCompatibleWallet).map((wallet) => new StandardWalletAdapter({ wallet }));
}
//#endregion
//#region node_modules/@solana/wallet-adapter-react/lib/esm/getEnvironment.js
var Environment;
(function(Environment) {
	Environment[Environment["DESKTOP_WEB"] = 0] = "DESKTOP_WEB";
	Environment[Environment["MOBILE_WEB"] = 1] = "MOBILE_WEB";
})(Environment || (Environment = {}));
function isWebView(userAgentString) {
	return /(WebView|Version\/.+(Chrome)\/(\d+)\.(\d+)\.(\d+)\.(\d+)|; wv\).+(Chrome)\/(\d+)\.(\d+)\.(\d+)\.(\d+))/i.test(userAgentString);
}
function getEnvironment({ adapters, userAgentString }) {
	if (adapters.some((adapter) => adapter.name !== SolanaMobileWalletAdapterWalletName && adapter.readyState === WalletReadyState.Installed))
 /**
	* There are only two ways a browser extension adapter should be able to reach `Installed` status:
	*
	*     1. Its browser extension is installed.
	*     2. The app is running on a mobile wallet's in-app browser.
	*
	* In either case, we consider the environment to be desktop-like.
	*/
	return Environment.DESKTOP_WEB;
	if (userAgentString && /android/i.test(userAgentString) && !isWebView(userAgentString)) return Environment.MOBILE_WEB;
	else return Environment.DESKTOP_WEB;
}
//#endregion
//#region node_modules/@solana/wallet-adapter-react/lib/esm/getInferredClusterFromEndpoint.js
function getInferredClusterFromEndpoint(endpoint) {
	if (!endpoint) return "mainnet-beta";
	if (/devnet/i.test(endpoint)) return "devnet";
	else if (/testnet/i.test(endpoint)) return "testnet";
	else return "mainnet-beta";
}
//#endregion
//#region node_modules/@solana/wallet-adapter-react/lib/esm/WalletProviderBase.js
function WalletProviderBase({ children, wallets: adapters, adapter, isUnloadingRef, onAutoConnectRequest, onConnectError, onError, onSelectWallet }) {
	const isConnectingRef = (0, import_react.useRef)(false);
	const [connecting, setConnecting] = (0, import_react.useState)(false);
	const isDisconnectingRef = (0, import_react.useRef)(false);
	const [disconnecting, setDisconnecting] = (0, import_react.useState)(false);
	const [publicKey, setPublicKey] = (0, import_react.useState)(() => adapter?.publicKey ?? null);
	const [connected, setConnected] = (0, import_react.useState)(() => adapter?.connected ?? false);
	/**
	* Store the error handlers as refs so that a change in the
	* custom error handler does not recompute other dependencies.
	*/
	const onErrorRef = (0, import_react.useRef)(onError);
	(0, import_react.useEffect)(() => {
		onErrorRef.current = onError;
		return () => {
			onErrorRef.current = void 0;
		};
	}, [onError]);
	const handleErrorRef = (0, import_react.useRef)((error, adapter) => {
		if (!isUnloadingRef.current) {
			if (onErrorRef.current) onErrorRef.current(error, adapter);
			else {
				console.error(error, adapter);
				if (error instanceof WalletNotReadyError && typeof window !== "undefined" && adapter) window.open(adapter.url, "_blank");
			}
		}
		return error;
	});
	const [wallets, setWallets] = (0, import_react.useState)(() => adapters.map((adapter) => ({
		adapter,
		readyState: adapter.readyState
	})).filter(({ readyState }) => readyState !== WalletReadyState.Unsupported));
	(0, import_react.useEffect)(() => {
		setWallets((wallets) => adapters.map((adapter, index) => {
			const wallet = wallets[index];
			return wallet && wallet.adapter === adapter && wallet.readyState === adapter.readyState ? wallet : {
				adapter,
				readyState: adapter.readyState
			};
		}).filter(({ readyState }) => readyState !== WalletReadyState.Unsupported));
		function handleReadyStateChange(readyState) {
			setWallets((prevWallets) => {
				const index = prevWallets.findIndex(({ adapter }) => adapter === this);
				if (index === -1) return prevWallets;
				const { adapter } = prevWallets[index];
				return [
					...prevWallets.slice(0, index),
					{
						adapter,
						readyState
					},
					...prevWallets.slice(index + 1)
				].filter(({ readyState }) => readyState !== WalletReadyState.Unsupported);
			});
		}
		adapters.forEach((adapter) => adapter.on("readyStateChange", handleReadyStateChange, adapter));
		return () => {
			adapters.forEach((adapter) => adapter.off("readyStateChange", handleReadyStateChange, adapter));
		};
	}, [adapter, adapters]);
	const wallet = (0, import_react.useMemo)(() => wallets.find((wallet) => wallet.adapter === adapter) ?? null, [adapter, wallets]);
	(0, import_react.useEffect)(() => {
		if (!adapter) return;
		const handleConnect = (publicKey) => {
			setPublicKey(publicKey);
			isConnectingRef.current = false;
			setConnecting(false);
			setConnected(true);
			isDisconnectingRef.current = false;
			setDisconnecting(false);
		};
		const handleDisconnect = () => {
			if (isUnloadingRef.current) return;
			setPublicKey(null);
			isConnectingRef.current = false;
			setConnecting(false);
			setConnected(false);
			isDisconnectingRef.current = false;
			setDisconnecting(false);
		};
		const handleError = (error) => {
			handleErrorRef.current(error, adapter);
		};
		adapter.on("connect", handleConnect);
		adapter.on("disconnect", handleDisconnect);
		adapter.on("error", handleError);
		return () => {
			adapter.off("connect", handleConnect);
			adapter.off("disconnect", handleDisconnect);
			adapter.off("error", handleError);
			handleDisconnect();
		};
	}, [adapter, isUnloadingRef]);
	const didAttemptAutoConnectRef = (0, import_react.useRef)(false);
	(0, import_react.useEffect)(() => {
		return () => {
			didAttemptAutoConnectRef.current = false;
		};
	}, [adapter]);
	(0, import_react.useEffect)(() => {
		if (didAttemptAutoConnectRef.current || isConnectingRef.current || connected || !onAutoConnectRequest || !(wallet?.readyState === WalletReadyState.Installed || wallet?.readyState === WalletReadyState.Loadable)) return;
		isConnectingRef.current = true;
		setConnecting(true);
		didAttemptAutoConnectRef.current = true;
		(async function() {
			try {
				await onAutoConnectRequest();
			} catch {
				onConnectError();
			} finally {
				setConnecting(false);
				isConnectingRef.current = false;
			}
		})();
	}, [
		connected,
		onAutoConnectRequest,
		onConnectError,
		wallet
	]);
	const sendTransaction = (0, import_react.useCallback)(async (transaction, connection, options) => {
		if (!adapter) throw handleErrorRef.current(new WalletNotSelectedError());
		if (!connected) throw handleErrorRef.current(new WalletNotConnectedError(), adapter);
		return await adapter.sendTransaction(transaction, connection, options);
	}, [adapter, connected]);
	const signTransaction = (0, import_react.useMemo)(() => adapter && "signTransaction" in adapter ? async (transaction) => {
		if (!connected) throw handleErrorRef.current(new WalletNotConnectedError(), adapter);
		return await adapter.signTransaction(transaction);
	} : void 0, [adapter, connected]);
	const signAllTransactions = (0, import_react.useMemo)(() => adapter && "signAllTransactions" in adapter ? async (transactions) => {
		if (!connected) throw handleErrorRef.current(new WalletNotConnectedError(), adapter);
		return await adapter.signAllTransactions(transactions);
	} : void 0, [adapter, connected]);
	const signMessage = (0, import_react.useMemo)(() => adapter && "signMessage" in adapter ? async (message) => {
		if (!connected) throw handleErrorRef.current(new WalletNotConnectedError(), adapter);
		return await adapter.signMessage(message);
	} : void 0, [adapter, connected]);
	const signIn = (0, import_react.useMemo)(() => adapter && "signIn" in adapter ? async (input) => {
		return await adapter.signIn(input);
	} : void 0, [adapter]);
	const handleConnect = (0, import_react.useCallback)(async () => {
		if (isConnectingRef.current || isDisconnectingRef.current || wallet?.adapter.connected) return;
		if (!wallet) throw handleErrorRef.current(new WalletNotSelectedError());
		const { adapter, readyState } = wallet;
		if (!(readyState === WalletReadyState.Installed || readyState === WalletReadyState.Loadable)) throw handleErrorRef.current(new WalletNotReadyError(), adapter);
		isConnectingRef.current = true;
		setConnecting(true);
		try {
			await adapter.connect();
		} catch (e) {
			onConnectError();
			throw e;
		} finally {
			setConnecting(false);
			isConnectingRef.current = false;
		}
	}, [onConnectError, wallet]);
	const handleDisconnect = (0, import_react.useCallback)(async () => {
		if (isDisconnectingRef.current) return;
		if (!adapter) return;
		isDisconnectingRef.current = true;
		setDisconnecting(true);
		try {
			await adapter.disconnect();
		} finally {
			setDisconnecting(false);
			isDisconnectingRef.current = false;
		}
	}, [adapter]);
	return import_react.createElement(WalletContext.Provider, { value: {
		autoConnect: !!onAutoConnectRequest,
		wallets,
		wallet,
		publicKey,
		connected,
		connecting,
		disconnecting,
		select: onSelectWallet,
		connect: handleConnect,
		disconnect: handleDisconnect,
		sendTransaction,
		signTransaction,
		signAllTransactions,
		signMessage,
		signIn
	} }, children);
}
//#endregion
//#region node_modules/@solana/wallet-adapter-react/lib/esm/WalletProvider.js
var _userAgent;
function getUserAgent() {
	if (_userAgent === void 0) _userAgent = globalThis.navigator?.userAgent ?? null;
	return _userAgent;
}
function getIsMobile(adapters) {
	return getEnvironment({
		adapters,
		userAgentString: getUserAgent()
	}) === Environment.MOBILE_WEB;
}
function getUriForAppIdentity() {
	const location = globalThis.location;
	if (!location) return;
	return `${location.protocol}//${location.host}`;
}
function WalletProvider({ children, wallets: adapters, autoConnect, localStorageKey = "walletName", onError }) {
	const { connection } = useConnection();
	const adaptersWithStandardAdapters = useStandardWalletAdapters(adapters);
	const mobileWalletAdapter = (0, import_react.useMemo)(() => {
		if (!getIsMobile(adaptersWithStandardAdapters)) return null;
		const existingMobileWalletAdapter = adaptersWithStandardAdapters.find((adapter) => adapter.name === SolanaMobileWalletAdapterWalletName);
		if (existingMobileWalletAdapter) return existingMobileWalletAdapter;
		return new SolanaMobileWalletAdapter({
			addressSelector: createDefaultAddressSelector(),
			appIdentity: { uri: getUriForAppIdentity() },
			authorizationResultCache: createDefaultAuthorizationResultCache(),
			cluster: getInferredClusterFromEndpoint(connection?.rpcEndpoint),
			onWalletNotFound: createDefaultWalletNotFoundHandler()
		});
	}, [adaptersWithStandardAdapters, connection?.rpcEndpoint]);
	const adaptersWithMobileWalletAdapter = (0, import_react.useMemo)(() => {
		if (mobileWalletAdapter == null || adaptersWithStandardAdapters.indexOf(mobileWalletAdapter) !== -1) return adaptersWithStandardAdapters;
		return [mobileWalletAdapter, ...adaptersWithStandardAdapters];
	}, [adaptersWithStandardAdapters, mobileWalletAdapter]);
	const [walletName, setWalletName] = useLocalStorage(localStorageKey, null);
	const adapter = (0, import_react.useMemo)(() => adaptersWithMobileWalletAdapter.find((a) => a.name === walletName) ?? null, [adaptersWithMobileWalletAdapter, walletName]);
	const changeWallet = (0, import_react.useCallback)((nextWalletName) => {
		if (walletName === nextWalletName) return;
		if (adapter && adapter.name !== SolanaMobileWalletAdapterWalletName) adapter.disconnect();
		setWalletName(nextWalletName);
	}, [
		adapter,
		setWalletName,
		walletName
	]);
	(0, import_react.useEffect)(() => {
		if (!adapter) return;
		function handleDisconnect() {
			if (isUnloadingRef.current) return;
			setWalletName(null);
		}
		adapter.on("disconnect", handleDisconnect);
		return () => {
			adapter.off("disconnect", handleDisconnect);
		};
	}, [
		adapter,
		adaptersWithStandardAdapters,
		setWalletName,
		walletName
	]);
	const hasUserSelectedAWallet = (0, import_react.useRef)(false);
	const handleAutoConnectRequest = (0, import_react.useMemo)(() => {
		if (!autoConnect || !adapter) return;
		return async () => {
			if (autoConnect === true || await autoConnect(adapter)) {
				if (hasUserSelectedAWallet.current) await adapter.connect();
				else await adapter.autoConnect();
			}
		};
	}, [autoConnect, adapter]);
	const isUnloadingRef = (0, import_react.useRef)(false);
	(0, import_react.useEffect)(() => {
		if (walletName === SolanaMobileWalletAdapterWalletName && getIsMobile(adaptersWithStandardAdapters)) {
			isUnloadingRef.current = false;
			return;
		}
		function handleBeforeUnload() {
			isUnloadingRef.current = true;
		}
		/**
		* Some wallets fire disconnection events when the window unloads. Since there's no way to
		* distinguish between a disconnection event received because a user initiated it, and one
		* that was received because they've closed the window, we have to track window unload
		* events themselves. Downstream components use this information to decide whether to act
		* upon or drop wallet events and errors.
		*/
		window.addEventListener("beforeunload", handleBeforeUnload);
		return () => {
			window.removeEventListener("beforeunload", handleBeforeUnload);
		};
	}, [adaptersWithStandardAdapters, walletName]);
	const handleConnectError = (0, import_react.useCallback)(() => {
		if (adapter) changeWallet(null);
	}, [adapter, changeWallet]);
	const selectWallet = (0, import_react.useCallback)((walletName) => {
		hasUserSelectedAWallet.current = true;
		changeWallet(walletName);
	}, [changeWallet]);
	return import_react.createElement(WalletProviderBase, {
		wallets: adaptersWithMobileWalletAdapter,
		adapter,
		isUnloadingRef,
		onAutoConnectRequest: handleAutoConnectRequest,
		onConnectError: handleConnectError,
		onError,
		onSelectWallet: selectWallet
	}, children);
}
//#endregion
export { useWallet as n, ConnectionProvider as r, WalletProvider as t };
