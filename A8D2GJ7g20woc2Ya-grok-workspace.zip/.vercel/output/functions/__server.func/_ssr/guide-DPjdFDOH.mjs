import { _ as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { s as LINKS } from "./constants-Qd1CV9hU.mjs";
import { a as CardDescription, i as CardContent, o as CardHeader, r as Card, s as CardTitle, t as AppShell } from "./card-CYNzzH5i.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/guide-DPjdFDOH.js
var import_jsx_runtime = require_jsx_runtime();
var STEPS = [
	{
		n: "01",
		title: "Install Nightly",
		body: "Nightly is the wallet Cookie Chain documents first. It ships Cookie as a built-in SVM network — no custom RPC paste required.",
		href: LINKS.nightly,
		cta: "Download Nightly"
	},
	{
		n: "02",
		title: "Switch to Cookie",
		body: "Open Nightly, use the network switcher (top right, under SVM), and select Cookie. A wallet still pointed at Solana mainnet will simulate the wrong chain and refuse to sign."
	},
	{
		n: "03",
		title: "Bridge COOK",
		body: "Fees are paid in COOK and are tiny — about 0.000005 COOK per signature. Bridge sCOOK from Solana through the Hyperlane warp route. Reserves sit in an m-of-n community multi-sig.",
		href: LINKS.bridge,
		cta: "Open the bridge",
		extra: LINKS.onboard,
		extraCta: "Visual onboard"
	},
	{
		n: "04",
		title: "Connect and bake",
		body: "Return here, connect Nightly, and bake a fortune, crumb, or pulse. You will sign in the wallet, then watch the transaction move from broadcast to confirmed on Cookiescan.",
		href: "/",
		cta: "Back to the jar",
		internal: true
	}
];
function Guide() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto max-w-3xl px-4 py-10 sm:py-14",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-medium uppercase tracking-[0.18em] text-muted",
				children: "Setup"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-3 font-display text-3xl font-medium leading-tight tracking-tight",
				children: "Get onto Cookie Chain"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-base leading-relaxed text-muted",
				children: "Four steps. After that, every bake is a real SVM transaction with a Cookiescan receipt."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
				className: "mt-10 space-y-4",
				children: STEPS.map((step) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-mono text-xs tabular-nums text-subtle",
						children: step.n
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: step.title }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardDescription, { children: step.body })
				] }), step.cta ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
					className: "flex flex-wrap gap-3",
					children: [step.internal ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						className: "inline-flex h-11 items-center rounded-md bg-primary px-4 text-sm font-medium text-primary-fg",
						children: step.cta
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: step.href,
						target: "_blank",
						rel: "noreferrer",
						className: "inline-flex h-11 items-center rounded-md bg-primary px-4 text-sm font-medium text-primary-fg",
						children: step.cta
					}), step.extra ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: step.extra,
						target: "_blank",
						rel: "noreferrer",
						className: "inline-flex h-11 items-center rounded-md px-4 text-sm text-muted shadow-border hover:text-fg",
						children: step.extraCta
					}) : null]
				}) : null] }) }, step.n))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-10 space-y-2 text-sm leading-relaxed text-muted",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-lg text-fg",
						children: "Useful links"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: ["RPC ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-mono text-2xs text-fg",
						children: "https://rpc.cookiescan.io"
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
						"DAS ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							className: "hover:text-fg",
							href: LINKS.das,
							children: LINKS.das
						}),
						" · ",
						"Swap ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							className: "hover:text-fg",
							href: LINKS.swap,
							children: "Cookieswap"
						}),
						" · ",
						"Liquidity ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							className: "hover:text-fg",
							href: LINKS.cookiebox,
							children: "Cookiebox"
						})
					] })
				]
			})
		]
	}) });
}
//#endregion
export { Guide as component };
