import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { _ as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as Slot, s as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { l as MEMO_PROGRAM_ID, n as COOKIE_DAS, o as LAMPORTS_PER_COOK, r as COOKIE_RPC, s as LINKS } from "./constants-Qd1CV9hU.mjs";
import { t as classifyMemo } from "./memo-DZXfzftw.mjs";
import { d as ChevronDown, f as Check, s as LogOut, t as Wallet, u as Copy } from "../_libs/lucide-react.mjs";
import { t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { N as Connection, P as PublicKey } from "../_libs/@solana-mobile/wallet-adapter-mobile.mjs";
import { n as useWallet } from "../_libs/@solana/wallet-adapter-react+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { a as Root2, i as Portal2, n as Item2, o as Separator2, r as Label2, s as Trigger, t as Content2 } from "../_libs/@radix-ui/react-dropdown-menu+[...].mjs";
import { t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { n as cn } from "./router-C5Cd44jQ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/card-CYNzzH5i.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function CookieMark({ className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 32 32",
		fill: "none",
		"aria-hidden": "true",
		className: cn("text-primary", className),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M9 8.5h14c.8 0 1.5.7 1.5 1.5v2.2c0 .4-.2.8-.5 1.1L22 15.6v8.9c0 1.1-.9 2-2 2H12c-1.1 0-2-.9-2-2v-8.9l-2-2.3c-.3-.3-.5-.7-.5-1.1V10c0-.8.7-1.5 1.5-1.5Z",
				stroke: "currentColor",
				strokeWidth: "1.6",
				strokeLinejoin: "round"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M11.5 8.5c0-2 2.2-3.7 4.5-3.7s4.5 1.7 4.5 3.7",
				stroke: "currentColor",
				strokeWidth: "1.6",
				strokeLinecap: "round"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M12.5 19.5h7M12.5 22.5h5",
				stroke: "currentColor",
				strokeWidth: "1.6",
				strokeLinecap: "round"
			})
		]
	});
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-[opacity,transform,background-color,color,box-shadow] duration-[var(--motion-quick)] ease-[var(--ease-out)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-bg disabled:pointer-events-none disabled:opacity-40 active:scale-[0.98] [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0", {
	variants: {
		variant: {
			default: "bg-primary text-primary-fg shadow-border hover:opacity-90",
			secondary: "bg-surface-2 text-fg shadow-border hover:bg-surface",
			outline: "bg-transparent text-fg shadow-border hover:bg-surface-2",
			ghost: "text-muted hover:bg-surface-2 hover:text-fg",
			destructive: "bg-danger text-fg hover:opacity-90"
		},
		size: {
			default: "h-11 px-4",
			sm: "h-9 px-3 text-xs",
			lg: "h-12 px-5",
			icon: "size-11"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
var Button = import_react.forwardRef(({ className, variant, size, asChild = false, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size,
			className
		})),
		ref,
		...props
	});
});
Button.displayName = "Button";
var DropdownMenu = Root2;
var DropdownMenuTrigger = Trigger;
var DropdownMenuContent = import_react.forwardRef(({ className, sideOffset = 6, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Portal2, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Content2, {
	ref,
	sideOffset,
	className: cn("z-50 min-w-52 overflow-hidden rounded-lg bg-surface p-1 text-fg shadow-border", className),
	...props
}) }));
DropdownMenuContent.displayName = Content2.displayName;
var DropdownMenuItem = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Item2, {
	ref,
	className: cn("relative flex cursor-pointer select-none items-center gap-2 rounded-md px-2.5 py-2 text-sm outline-none data-disabled:pointer-events-none data-disabled:opacity-40 data-highlighted:bg-surface-2", className),
	...props
}));
DropdownMenuItem.displayName = Item2.displayName;
var DropdownMenuLabel = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label2, {
	ref,
	className: cn("px-2.5 py-1.5 text-xs font-medium text-muted", className),
	...props
}));
DropdownMenuLabel.displayName = Label2.displayName;
var DropdownMenuSeparator = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Separator2, {
	ref,
	className: cn("-mx-1 my-1 h-px bg-border", className),
	...props
}));
DropdownMenuSeparator.displayName = Separator2.displayName;
var connection = null;
function getConnection() {
	if (!connection) connection = new Connection(COOKIE_RPC, {
		commitment: "confirmed",
		disableRetryOnRateLimit: false
	});
	return connection;
}
async function dasRpc(method, params) {
	const res = await fetch(COOKIE_DAS, {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify({
			jsonrpc: "2.0",
			id: "jar",
			method,
			params
		})
	});
	if (!res.ok) throw new Error(`DAS ${res.status}`);
	const body = await res.json();
	if (body.error) throw new Error(body.error.message);
	if (body.result === void 0) throw new Error("DAS returned no result");
	return body.result;
}
async function fetchNetworkSnapshot() {
	const connection = getConnection();
	const started = performance.now();
	const [epoch, samples, votes] = await Promise.all([
		connection.getEpochInfo(),
		connection.getRecentPerformanceSamples(24),
		connection.getVoteAccounts()
	]);
	const latencyMs = Math.round(performance.now() - started);
	const mapped = [...samples].reverse().map((s) => {
		const extra = s;
		const period = extra.samplePeriodSecs || 60;
		return {
			slot: extra.slot,
			period,
			tps: (extra.numTransactions || 0) / period,
			nonVoteTps: (extra.numNonVoteTransactions || 0) / period
		};
	});
	const last = mapped.slice(-8);
	const tps = last.reduce((sum, s) => sum + s.tps, 0) / Math.max(1, last.length);
	const nonVoteTps = last.reduce((sum, s) => sum + s.nonVoteTps, 0) / Math.max(1, last.length);
	return {
		slot: epoch.absoluteSlot,
		blockHeight: epoch.blockHeight ?? epoch.absoluteSlot,
		epoch: epoch.epoch,
		slotIndex: epoch.slotIndex,
		slotsInEpoch: epoch.slotsInEpoch,
		transactionCount: epoch.transactionCount ?? 0,
		epochProgress: epoch.slotsInEpoch ? epoch.slotIndex / epoch.slotsInEpoch : 0,
		tps,
		nonVoteTps,
		samples: mapped,
		validatorCount: votes.current.length,
		delinquentCount: votes.delinquent.length,
		latencyMs,
		fetchedAt: Date.now()
	};
}
async function fetchCulture(limit = 18) {
	return (await getConnection().getSignaturesForAddress(new PublicKey(MEMO_PROGRAM_ID), { limit })).map(toCultureItem);
}
function toCultureItem(info) {
	const memo = info.memo ?? "";
	return {
		signature: info.signature,
		slot: info.slot,
		blockTime: info.blockTime ?? null,
		err: Boolean(info.err),
		memo,
		classified: classifyMemo(memo)
	};
}
async function fetchHoldings(owner) {
	return ((await dasRpc("getAssetsByOwner", {
		ownerAddress: owner,
		page: 1,
		limit: 40,
		displayOptions: {
			showFungible: true,
			showZeroBalance: false
		}
	})).items ?? []).map((asset) => {
		const decimals = asset.token_info?.decimals ?? 0;
		const raw = asset.token_info?.balance ?? 0;
		const uiAmount = decimals > 0 ? raw / 10 ** decimals : raw;
		return {
			mint: asset.id,
			name: asset.content?.metadata?.name || "Unknown",
			symbol: asset.token_info?.symbol || asset.content?.metadata?.symbol || "???",
			amount: raw,
			decimals,
			uiAmount
		};
	}).filter((h) => h.uiAmount > 0).sort((a, b) => b.uiAmount - a.uiAmount);
}
async function fetchBalance(address) {
	return await getConnection().getBalance(new PublicKey(address), "confirmed");
}
async function fetchRecentWalletTxs(address, limit = 8) {
	return (await getConnection().getSignaturesForAddress(new PublicKey(address), { limit })).map(toCultureItem);
}
function shortAddress(address, size = 4) {
	if (address.length <= size * 2 + 1) return address;
	return `${address.slice(0, size)}…${address.slice(-size)}`;
}
function lamportsToCook(lamports, digits = 4) {
	const value = lamports / LAMPORTS_PER_COOK;
	if (value === 0) return "0";
	if (value < 1e-4) return value.toExponential(2);
	return value.toLocaleString(void 0, {
		maximumFractionDigits: digits,
		minimumFractionDigits: 0
	});
}
function formatCompact(n, digits = 2) {
	if (!Number.isFinite(n)) return "—";
	return new Intl.NumberFormat(void 0, {
		notation: "compact",
		maximumFractionDigits: digits
	}).format(n);
}
function formatInt(n) {
	if (!Number.isFinite(n)) return "—";
	return new Intl.NumberFormat(void 0).format(n);
}
function formatAgo(unixSeconds) {
	if (!unixSeconds) return "just now";
	const delta = Math.max(0, Date.now() / 1e3 - unixSeconds);
	if (delta < 8) return "now";
	if (delta < 60) return `${Math.floor(delta)}s ago`;
	if (delta < 3600) return `${Math.floor(delta / 60)}m ago`;
	if (delta < 86400) return `${Math.floor(delta / 3600)}h ago`;
	return `${Math.floor(delta / 86400)}d ago`;
}
function useMounted() {
	const [mounted, setMounted] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => setMounted(true), []);
	return mounted;
}
function WalletConnect() {
	const mounted = useMounted();
	const { wallets, select, disconnect, connected, connecting, publicKey, wallet } = useWallet();
	const [copied, setCopied] = (0, import_react.useState)(false);
	const sorted = (0, import_react.useMemo)(() => {
		return [...wallets.map((w) => w.adapter)].sort((a, b) => {
			return (a.name.toLowerCase().includes("nightly") ? -1 : 0) - (b.name.toLowerCase().includes("nightly") ? -1 : 0);
		});
	}, [wallets]);
	const address = publicKey?.toBase58();
	const balance = useQuery({
		queryKey: ["cook-balance", address],
		queryFn: () => fetchBalance(address),
		enabled: Boolean(address),
		refetchInterval: 12e3
	});
	function onSelect(name) {
		try {
			select(name);
		} catch (err) {
			const msg = err instanceof Error ? err.message : "Could not connect wallet";
			if (!/reject|denied|cancel/i.test(msg)) toast.error(msg);
		}
	}
	async function copyAddress() {
		if (!address) return;
		await navigator.clipboard.writeText(address);
		setCopied(true);
		toast.success("Address copied");
		window.setTimeout(() => setCopied(false), 1400);
	}
	if (!mounted) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
		variant: "secondary",
		size: "sm",
		disabled: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wallet, {}), "Wallet"]
	});
	if (connected && address) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenu, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuTrigger, {
		asChild: true,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
			variant: "secondary",
			size: "sm",
			className: "max-w-[11.5rem]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-1.5 shrink-0 rounded-full bg-success" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "truncate font-mono text-xs tabular-nums",
					children: shortAddress(address)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "size-3.5 opacity-60" })
			]
		})
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuContent, {
		align: "end",
		className: "w-64",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuLabel, { children: wallet?.adapter.name ?? "Wallet" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "px-2.5 pb-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-mono text-[0.6875rem] text-muted break-all",
					children: address
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 font-mono text-sm tabular-nums text-fg",
					children: balance.isLoading ? "…" : `${lamportsToCook(balance.data ?? 0, 5)} COOK`
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuSeparator, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuItem, {
				onSelect: () => void copyAddress(),
				children: [copied ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, {}), "Copy address"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuItem, {
				onSelect: () => void disconnect(),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, {}), "Disconnect"]
			})
		]
	})] });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenu, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuTrigger, {
		asChild: true,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
			size: "sm",
			disabled: connecting,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wallet, {}), connecting ? "Connecting" : "Connect wallet"]
		})
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuContent, {
		align: "end",
		className: "w-64",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuLabel, { children: "Cookie Chain wallet" }),
			sorted.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "px-2.5 py-2 text-sm text-muted",
				children: "No Wallet Standard wallet found. Install Nightly, switch it to Cookie, then refresh."
			}) : sorted.map((adapter) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuItem, {
				onSelect: () => onSelect(adapter.name),
				children: [
					adapter.icon ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: adapter.icon,
						alt: "",
						className: "size-4 rounded-sm",
						crossOrigin: "anonymous"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wallet, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: adapter.name }),
					adapter.name.toLowerCase().includes("nightly") ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "ml-auto text-2xs text-muted",
						children: "Required"
					}) : null
				]
			}, adapter.name)),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuSeparator, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuItem, {
				asChild: true,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: LINKS.nightly,
					target: "_blank",
					rel: "noreferrer",
					children: "Get Nightly"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuItem, {
				asChild: true,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: LINKS.bridge,
					target: "_blank",
					rel: "noreferrer",
					children: "Bridge COOK"
				})
			})
		]
	})] });
}
function AppShell({ children }) {
	const net = useQuery({
		queryKey: ["network"],
		queryFn: fetchNetworkSnapshot,
		refetchInterval: 5e3
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-bg text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: "sticky top-0 z-40 border-b border-border bg-bg/90 backdrop-blur-sm",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex h-16 max-w-6xl items-center justify-between gap-3 px-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/",
						className: "flex items-center gap-2.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CookieMark, { className: "size-7" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-display text-lg tracking-tight",
							children: "The Jar"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2 sm:gap-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "hidden items-center gap-2 font-mono text-xs tabular-nums text-muted sm:inline-flex",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-1.5 rounded-full bg-success" }), net.data ? `slot ${formatInt(net.data.slot)}` : "connecting"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/guide",
								className: "hidden h-11 items-center px-2 text-sm text-muted hover:text-fg md:inline-flex",
								children: "Setup"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WalletConnect, {})
						]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
				className: "border-t border-border",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex max-w-6xl flex-col gap-3 px-4 py-8 text-xs text-subtle sm:flex-row sm:items-center sm:justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "The Jar · on-chain fortunes for Cookie Chain" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
						className: "flex flex-wrap gap-x-4 gap-y-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: LINKS.bridge,
								target: "_blank",
								rel: "noreferrer",
								className: "hover:text-fg",
								children: "Bridge"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: LINKS.swap,
								target: "_blank",
								rel: "noreferrer",
								className: "hover:text-fg",
								children: "Cookieswap"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: LINKS.cookiebox,
								target: "_blank",
								rel: "noreferrer",
								className: "hover:text-fg",
								children: "Cookiebox"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: LINKS.explorer,
								target: "_blank",
								rel: "noreferrer",
								className: "hover:text-fg",
								children: "Cookiescan"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: LINKS.docs,
								target: "_blank",
								rel: "noreferrer",
								className: "hover:text-fg",
								children: "Docs"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: LINKS.nightly,
								target: "_blank",
								rel: "noreferrer",
								className: "hover:text-fg",
								children: "Nightly"
							})
						]
					})]
				})
			})
		]
	});
}
var Card = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	ref,
	className: cn("rounded-xl bg-surface text-fg shadow-border", className),
	...props
}));
Card.displayName = "Card";
var CardHeader = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	ref,
	className: cn("flex flex-col gap-1 p-5 pb-3", className),
	...props
}));
CardHeader.displayName = "CardHeader";
var CardTitle = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
	ref,
	className: cn("font-display text-lg font-medium leading-snug tracking-tight", className),
	...props
}));
CardTitle.displayName = "CardTitle";
var CardDescription = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
	ref,
	className: cn("text-sm leading-normal text-muted", className),
	...props
}));
CardDescription.displayName = "CardDescription";
var CardContent = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	ref,
	className: cn("p-5 pt-0", className),
	...props
}));
CardContent.displayName = "CardContent";
var CardFooter = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	ref,
	className: cn("flex items-center p-5 pt-0", className),
	...props
}));
CardFooter.displayName = "CardFooter";
//#endregion
export { lamportsToCook as _, CardDescription as a, fetchBalance as c, fetchNetworkSnapshot as d, fetchRecentWalletTxs as f, getConnection as g, formatInt as h, CardContent as i, fetchCulture as l, formatCompact as m, Button as n, CardHeader as o, formatAgo as p, Card as r, CardTitle as s, AppShell as t, fetchHoldings as u, shortAddress as v, useMounted as y };
