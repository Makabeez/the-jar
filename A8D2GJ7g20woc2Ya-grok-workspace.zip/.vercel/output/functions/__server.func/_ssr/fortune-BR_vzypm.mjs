import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
import { c as LOCAL_FORTUNES } from "./constants-Qd1CV9hU.mjs";
import { r as pickLocalFortune } from "./memo-DZXfzftw.mjs";
import { i as string, n as number, r as object } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/fortune-BR_vzypm.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var inputSchema = object({
	question: string().trim().min(3).max(160),
	slot: number().int().nonnegative().optional()
});
function localFortune(question, slot) {
	const idx = pickLocalFortune(`${question}|${slot ?? 0}`) % LOCAL_FORTUNES.length;
	return LOCAL_FORTUNES[idx] ?? LOCAL_FORTUNES[0];
}
var askOracle_createServerFn_handler = createServerRpc({
	id: "361728c8a58723e67535d79dbfe5f51b196578a927eac6aad4e8a489baa314fe",
	name: "askOracle",
	filename: "src/lib/fortune.ts"
}, (opts) => askOracle.__executeServer(opts));
var askOracle = createServerFn({ method: "POST" }).validator((input) => inputSchema.parse(input)).handler(askOracle_createServerFn_handler, async ({ data }) => {
	const fallback = localFortune(data.question, data.slot);
	const apiKey = process.env.XAI_API_KEY;
	if (!apiKey) return {
		ok: true,
		text: fallback,
		source: "jar"
	};
	try {
		const res = await fetch("https://api.x.ai/v1/chat/completions", {
			method: "POST",
			headers: {
				"Content-Type": "application/json",
				Authorization: `Bearer ${apiKey}`
			},
			signal: AbortSignal.timeout(12e3),
			body: JSON.stringify({
				model: "grok-4.5",
				temperature: .95,
				max_tokens: 80,
				messages: [{
					role: "system",
					content: "You are The Jar, an oracle on Cookie Chain, a community-run SVM. Write one short fortune, at most two sentences and under 200 characters. Dry, slightly degen, bakery-kitchen tone. No emoji, no hashtags, no quotes around the whole answer, no preamble."
				}, {
					role: "user",
					content: `Question from a baker: ${data.question}`
				}]
			})
		});
		if (!res.ok) return {
			ok: true,
			text: fallback,
			source: "jar"
		};
		const text = (await res.json()).choices?.[0]?.message?.content?.trim();
		if (!text) return {
			ok: true,
			text: fallback,
			source: "jar"
		};
		return {
			ok: true,
			text: text.replace(/^["“]|["”]$/g, "").slice(0, 200),
			source: "oracle"
		};
	} catch {
		return {
			ok: true,
			text: fallback,
			source: "jar"
		};
	}
});
//#endregion
export { askOracle_createServerFn_handler };
