import { a as JAR_PREFIX } from "./constants-Qd1CV9hU.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/memo-DZXfzftw.js
function stripLenPrefix(memo) {
	return memo.replace(/^\[\d+\]\s*/, "").trim();
}
function clip(text, max) {
	const t = text.replace(/\|/g, "/").replace(/\s+/g, " ").trim();
	if (t.length <= max) return t;
	return t.slice(0, max - 1).trimEnd() + "…";
}
function encodeJarMemo(kind, a, b) {
	if (kind === "pulse") return `${JAR_PREFIX}|pulse|${Date.now()}`;
	if (kind === "crumb") return `${JAR_PREFIX}|crumb|${clip(a ?? "", 240)}`;
	return `${JAR_PREFIX}|fortune|${clip(a ?? "", 160)}|${clip(b ?? "", 200)}`;
}
function classifyMemo(raw) {
	const text = stripLenPrefix(raw ?? "");
	if (!text) return {
		kind: "culture",
		title: "Silent tx",
		body: "Memo left empty.",
		fromJar: false
	};
	if (text.startsWith(`jar:v1|`)) {
		const parts = text.split("|");
		const kind = parts[1];
		if (kind === "fortune") {
			const question = parts[2] ?? "";
			return {
				kind: "fortune",
				title: "Fortune",
				body: parts.slice(3).join("|") || text,
				question: question || void 0,
				fromJar: true
			};
		}
		if (kind === "crumb") return {
			kind: "crumb",
			title: "Crumb",
			body: parts.slice(2).join("|") || text,
			fromJar: true
		};
		if (kind === "pulse") return {
			kind: "pulse",
			title: "Pulse",
			body: "A baker pinged the chain.",
			fromJar: true
		};
		return {
			kind: "crumb",
			title: "The Jar",
			body: text,
			fromJar: true
		};
	}
	if (/cookie monster burn|deflation: burned/i.test(text)) return {
		kind: "burn",
		title: "Burn",
		body: text,
		fromJar: false
	};
	if (/cookieagent|telemetry sentinel/i.test(text)) return {
		kind: "agent",
		title: "Agent",
		body: text,
		fromJar: false
	};
	if (/cookiearena:/i.test(text)) return {
		kind: "arena",
		title: "Arena",
		body: text,
		fromJar: false
	};
	if (/keno:v1/i.test(text)) return {
		kind: "keno",
		title: "Keno",
		body: text,
		fromJar: false
	};
	if (/cookieswap/i.test(text)) return {
		kind: "swap",
		title: "Swap",
		body: text,
		fromJar: false
	};
	if (/hyperarb vault|vault (deposit|withdraw)/i.test(text)) return {
		kind: "vault",
		title: "Vault",
		body: text,
		fromJar: false
	};
	if (/ovenpit|oven:/i.test(text)) return {
		kind: "oven",
		title: "Oven",
		body: text,
		fromJar: false
	};
	return {
		kind: "culture",
		title: text.split(/[:|\-–]/)[0]?.trim().slice(0, 28) || "Memo",
		body: text,
		fromJar: false
	};
}
function pickLocalFortune(seed) {
	let h = 2166136261;
	for (let i = 0; i < seed.length; i++) {
		h ^= seed.charCodeAt(i);
		h = Math.imul(h, 16777619);
	}
	return Math.abs(h);
}
//#endregion
export { encodeJarMemo as n, pickLocalFortune as r, classifyMemo as t };
