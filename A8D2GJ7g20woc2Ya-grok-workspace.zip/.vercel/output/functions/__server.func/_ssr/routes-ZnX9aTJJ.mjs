import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
import { d as explorerTx, i as GENESIS_HASH, l as MEMO_PROGRAM_ID, s as LINKS, t as AVG_FEE_COOK, u as explorerAccount } from "./constants-Qd1CV9hU.mjs";
import { n as encodeJarMemo } from "./memo-DZXfzftw.mjs";
import { i as string, n as number, r as object } from "../_libs/zod.mjs";
import { a as ScrollText, c as LoaderCircle, f as Check, i as ShieldAlert, l as Flame, o as Radio, p as ArrowUpRight, r as Sparkles } from "../_libs/lucide-react.mjs";
import { r as useQueryClient, t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { F as SystemProgram, I as Transaction, L as TransactionInstruction, P as PublicKey } from "../_libs/@solana-mobile/wallet-adapter-mobile.mjs";
import { n as useWallet } from "../_libs/@solana/wallet-adapter-react+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { n as cn } from "./router-C5Cd44jQ.mjs";
import { _ as lamportsToCook, a as CardDescription, c as fetchBalance, d as fetchNetworkSnapshot, f as fetchRecentWalletTxs, g as getConnection, h as formatInt, i as CardContent, l as fetchCulture, m as formatCompact, n as Button, o as CardHeader, p as formatAgo, r as Card, s as CardTitle, t as AppShell, u as fetchHoldings, v as shortAddress, y as useMounted } from "./card-CYNzzH5i.mjs";
import { a as ResponsiveContainer, i as Area, n as YAxis, o as Tooltip, r as XAxis, t as AreaChart } from "../_libs/recharts+[...].mjs";
import { i as Trigger, n as List, r as Root2, t as Content } from "../_libs/radix-ui__react-tabs.mjs";
import { Buffer } from "buffer";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-ZnX9aTJJ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Skeleton({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("animate-pulse rounded-md bg-surface-2", className),
		...props
	});
}
function Stat({ label, value, hint }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-lg bg-surface-2 px-3 py-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[0.6875rem] font-medium uppercase tracking-wide text-subtle",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 font-mono text-lg tabular-nums leading-none text-fg",
				children: value
			}),
			hint ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-[0.6875rem] text-subtle",
				children: hint
			}) : null
		]
	});
}
function ChainDashboard() {
	const query = useQuery({
		queryKey: ["network"],
		queryFn: fetchNetworkSnapshot,
		refetchInterval: 5e3
	});
	const n = query.data;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center justify-between gap-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Chain pulse" }), n ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "inline-flex items-center gap-1.5 text-xs text-success",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-1.5 rounded-full bg-success" }),
				"Live · ",
				n.latencyMs,
				" ms"
			]
		}) : null]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardDescription, { children: ["Cookie Chain SVM · genesis ", shortAddress(GENESIS_HASH, 4)] })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
		className: "space-y-4",
		children: query.isLoading || !n ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid grid-cols-2 gap-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-20" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-20" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-20" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-20" })
			]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Slot",
						value: formatInt(n.slot)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Block height",
						value: formatInt(n.blockHeight)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "TPS",
						value: n.tps.toFixed(1),
						hint: `${n.nonVoteTps.toFixed(2)} non-vote`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Epoch",
						value: `${n.epoch}`,
						hint: `${Math.round(n.epochProgress * 100)}% · ${formatInt(n.slotIndex)} / ${formatInt(n.slotsInEpoch)}`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Transactions",
						value: formatCompact(n.transactionCount)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Validators",
						value: `${n.validatorCount}`,
						hint: n.delinquentCount ? `${n.delinquentCount} delinquent` : "none delinquent"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-2 text-[0.6875rem] font-medium uppercase tracking-wide text-subtle",
				children: "TPS · last samples"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "h-36",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
					width: "100%",
					height: "100%",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AreaChart, {
						data: n.samples,
						margin: {
							top: 4,
							right: 4,
							left: -22,
							bottom: 0
						},
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
								dataKey: "slot",
								hide: true
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
								tick: {
									fill: "var(--color-subtle)",
									fontSize: 10
								},
								width: 40
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {
								contentStyle: {
									background: "var(--color-surface-2)",
									border: "none",
									borderRadius: 8,
									color: "var(--color-fg)",
									fontSize: 12
								},
								labelFormatter: (label) => `slot ${label}`,
								formatter: (value) => [Number(value).toFixed(2), "TPS"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Area, {
								type: "monotone",
								dataKey: "tps",
								stroke: "var(--color-primary)",
								fill: "var(--color-primary)",
								fillOpacity: .12,
								strokeWidth: 1.5,
								isAnimationActive: false
							})
						]
					})
				})
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-[0.6875rem] leading-normal text-subtle",
				children: [
					"Avg fee ",
					AVG_FEE_COOK,
					" COOK per signature.",
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						className: "text-muted underline-offset-2 hover:text-fg hover:underline",
						href: explorerAccount(GENESIS_HASH),
						target: "_blank",
						rel: "noreferrer",
						children: "Explorer"
					})
				]
			})
		] })
	})] });
}
var badgeVariants = cva("inline-flex items-center rounded-full px-2 py-0.5 text-[0.6875rem] font-medium tracking-wide", {
	variants: { variant: {
		default: "bg-surface-2 text-muted",
		solid: "bg-primary text-primary-fg",
		fortune: "bg-surface-2 text-fg",
		crumb: "bg-surface-2 text-fg",
		pulse: "bg-surface-2 text-muted",
		burn: "bg-danger-soft text-danger",
		agent: "bg-success-soft text-success",
		live: "bg-success-soft text-success"
	} },
	defaultVariants: { variant: "default" }
});
function Badge({ className, variant, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn(badgeVariants({ variant }), className),
		...props
	});
}
var KIND_VARIANT = {
	fortune: "fortune",
	crumb: "crumb",
	pulse: "pulse",
	burn: "burn",
	agent: "agent"
};
function matches(filter, item) {
	if (filter === "all") return true;
	if (filter === "jar") return item.classified.fromJar;
	return !item.classified.fromJar;
}
function CultureRadar() {
	const [filter, setFilter] = (0, import_react.useState)("all");
	const query = useQuery({
		queryKey: ["culture"],
		queryFn: () => fetchCulture(18),
		refetchInterval: 12e3
	});
	const items = (0, import_react.useMemo)(() => (query.data ?? []).filter((item) => matches(filter, item) && !item.err), [query.data, filter]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, {
		className: "flex-row items-start justify-between gap-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Culture radar" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardDescription, { children: "Live SPL memos from Cookie Chain — burns, agents, arenas, and inscriptions from this jar." })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex shrink-0 gap-1 rounded-lg bg-surface-2 p-1",
			children: [
				"all",
				"jar",
				"chain"
			].map((id) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => setFilter(id),
				className: cn("h-8 rounded-md px-2.5 text-xs font-medium capitalize", filter === id ? "bg-surface text-fg shadow-border" : "text-muted hover:text-fg"),
				children: id
			}, id))
		})]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, { children: query.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-16" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-16" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-16" })
		]
	}) : query.isError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-sm text-muted",
		children: "Could not read memos from the RPC. The chain is still there — try a refresh."
	}) : items.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-sm text-muted",
		children: filter === "jar" ? "The jar is empty. Bake a fortune, crumb, or pulse to leave the first inscription." : "No memos in this window."
	}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "divide-y divide-border",
		children: items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
			className: "py-3 first:pt-0 last:pb-0",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								variant: KIND_VARIANT[item.classified.kind] ?? "default",
								children: item.classified.title
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "font-mono text-[0.6875rem] tabular-nums text-subtle",
								children: [
									formatAgo(item.blockTime),
									" · slot ",
									item.slot.toLocaleString()
								]
							})]
						}),
						item.classified.question ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1.5 text-xs text-subtle",
							children: item.classified.question
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm leading-relaxed text-fg text-pretty",
							children: item.classified.body
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: explorerTx(item.signature),
					target: "_blank",
					rel: "noreferrer",
					className: "mt-0.5 inline-flex size-9 shrink-0 items-center justify-center rounded-md text-muted hover:bg-surface-2 hover:text-fg",
					"aria-label": "Open on Cookiescan",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, { className: "size-4" })
				})]
			})
		}, item.signature))
	}) })] });
}
var Input = import_react.forwardRef(({ className, type, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
	type,
	className: cn("flex h-11 w-full rounded-md bg-surface-2 px-3 text-sm text-fg shadow-border transition-[box-shadow] duration-[var(--motion-quick)] placeholder:text-subtle focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50", className),
	ref,
	...props
}));
Input.displayName = "Input";
var Tabs = Root2;
var TabsList = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(List, {
	ref,
	className: cn("inline-flex h-11 w-full items-center justify-start gap-1 rounded-lg bg-surface-2 p-1", className),
	...props
}));
TabsList.displayName = List.displayName;
var TabsTrigger = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trigger, {
	ref,
	className: cn("inline-flex h-9 flex-1 items-center justify-center gap-1.5 rounded-md px-3 text-sm font-medium text-muted transition-[background-color,color] duration-[var(--motion-quick)] data-[state=active]:bg-surface data-[state=active]:text-fg data-[state=active]:shadow-border [&_svg]:size-3.5", className),
	...props
}));
TabsTrigger.displayName = Trigger.displayName;
var TabsContent = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Content, {
	ref,
	className: cn("mt-4 outline-none", className),
	...props
}));
TabsContent.displayName = Content.displayName;
var Textarea = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
	className: cn("flex min-h-28 w-full rounded-md bg-surface-2 px-3 py-2.5 text-sm text-fg shadow-border transition-[box-shadow] duration-[var(--motion-quick)] placeholder:text-subtle focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50", className),
	ref,
	...props
}));
Textarea.displayName = "Textarea";
var STEPS = [
	{
		id: "signing",
		label: "Sign"
	},
	{
		id: "sent",
		label: "Broadcast"
	},
	{
		id: "confirming",
		label: "Confirm"
	},
	{
		id: "confirmed",
		label: "Final"
	}
];
function rank(phase) {
	if (phase === "idle") return -1;
	if (phase === "error") return -1;
	return STEPS.findIndex((s) => s.id === phase);
}
function TxStatus({ phase, signature, error }) {
	if (phase === "idle" && !error) return null;
	const current = rank(phase);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-4 rounded-lg bg-surface-2 p-3 shadow-border",
		children: [phase !== "error" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
			className: "grid grid-cols-4 gap-1",
			children: STEPS.map((step, i) => {
				const done = current > i || phase === "confirmed";
				const active = step.id === phase;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex flex-col items-center gap-1.5 text-center",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: cn("flex size-6 items-center justify-center rounded-full text-[0.625rem] font-medium", done || active ? "bg-primary text-primary-fg" : "bg-bg text-subtle"),
						children: done && !active ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-3" }) : active && phase !== "confirmed" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-3 animate-spin" }) : active ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-3" }) : i + 1
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: cn("text-[0.6875rem]", active ? "text-fg" : "text-subtle"),
						children: step.label
					})]
				}, step.id);
			})
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "flex items-start gap-2 text-sm text-danger",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldAlert, { className: "mt-0.5 size-4 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: error || "The transaction did not land." })]
		}), signature ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
			href: explorerTx(signature),
			target: "_blank",
			rel: "noreferrer",
			className: "mt-3 flex items-center gap-1.5 font-mono text-xs text-muted hover:text-fg",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Radio, { className: "size-3.5" }),
				shortAddress(signature, 6),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-subtle",
					children: "on Cookiescan"
				})
			]
		}) : null]
	});
}
var TxUserError = class extends Error {
	constructor(message) {
		super(message);
		this.name = "TxUserError";
	}
};
function friendlyError(err) {
	const raw = err instanceof Error ? err.message : typeof err === "string" ? err : "Transaction failed";
	const msg = raw.toLowerCase();
	if (msg.includes("reject") || msg.includes("denied") || msg.includes("cancel")) return "Signature request was rejected in the wallet.";
	if (msg.includes("insufficient") || msg.includes("no record of a prior credit")) return "Not enough COOK to cover the fee. Bridge a little from Solana, then retry.";
	if (msg.includes("blockhash") || msg.includes("expired") || msg.includes("not confirmed")) return "The blockhash expired before confirmation. Try baking again.";
	if (msg.includes("network") || msg.includes("failed to fetch") || msg.includes("429")) return "Cookie Chain RPC is busy or unreachable. Wait a moment and retry.";
	if (msg.includes("wallet not connected") || msg.includes("not connected")) return "Connect Nightly (or another Cookie-network wallet) first.";
	return raw.length > 180 ? `${raw.slice(0, 177)}…` : raw;
}
async function bakeMemo(wallet, memo, onPhase) {
	const { publicKey, signTransaction, connected } = wallet;
	if (!connected || !publicKey || !signTransaction) throw new TxUserError("Connect Nightly (or another Cookie-network wallet) first.");
	if (!memo.trim()) throw new TxUserError("Nothing to bake — write a crumb first.");
	const connection = getConnection();
	const memoIx = new TransactionInstruction({
		keys: [{
			pubkey: publicKey,
			isSigner: true,
			isWritable: false
		}],
		programId: new PublicKey(MEMO_PROGRAM_ID),
		data: Buffer.from(memo, "utf8")
	});
	const transferIx = SystemProgram.transfer({
		fromPubkey: publicKey,
		toPubkey: publicKey,
		lamports: 1
	});
	const send = async (withMemo) => {
		const { blockhash, lastValidBlockHeight } = await connection.getLatestBlockhash("confirmed");
		const tx = new Transaction();
		tx.feePayer = publicKey;
		tx.recentBlockhash = blockhash;
		tx.add(transferIx);
		if (withMemo) tx.add(memoIx);
		onPhase?.("signing");
		const signed = await signTransaction(tx);
		onPhase?.("sent");
		const signature = await connection.sendRawTransaction(signed.serialize(), {
			skipPreflight: false,
			preflightCommitment: "confirmed",
			maxRetries: 3
		});
		onPhase?.("confirming", signature);
		if ((await connection.confirmTransaction({
			signature,
			blockhash,
			lastValidBlockHeight
		}, "confirmed")).value.err) throw new Error("On-chain program returned an error.");
		onPhase?.("confirmed", signature);
		return signature;
	};
	try {
		return {
			signature: await send(true),
			status: "confirmed"
		};
	} catch (err) {
		const msg = err instanceof Error ? err.message.toLowerCase() : "";
		if (!(msg.includes("reject") || msg.includes("denied") || msg.includes("cancel"))) try {
			return {
				signature: await send(false),
				status: "confirmed"
			};
		} catch (retryErr) {
			throw new TxUserError(friendlyError(retryErr));
		}
		throw new TxUserError(friendlyError(err));
	}
}
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var inputSchema = object({
	question: string().trim().min(3).max(160),
	slot: number().int().nonnegative().optional()
});
var askOracle = createServerFn({ method: "POST" }).validator((input) => inputSchema.parse(input)).handler(createSsrRpc("361728c8a58723e67535d79dbfe5f51b196578a927eac6aad4e8a489baa314fe"));
var KEY = "the-jar:bakes";
function loadBakes() {
	if (typeof window === "undefined") return [];
	try {
		const raw = window.localStorage.getItem(KEY);
		if (!raw) return [];
		const parsed = JSON.parse(raw);
		return Array.isArray(parsed) ? parsed.slice(0, 40) : [];
	} catch {
		return [];
	}
}
function rememberBake(bake) {
	if (typeof window === "undefined") return;
	const next = [bake, ...loadBakes().filter((b) => b.signature !== bake.signature)].slice(0, 40);
	window.localStorage.setItem(KEY, JSON.stringify(next));
	window.dispatchEvent(new Event("jar:bakes"));
}
function OvenPanel({ slot }) {
	const mounted = useMounted();
	const wallet = useWallet();
	const queryClient = useQueryClient();
	const [tab, setTab] = (0, import_react.useState)("fortune");
	const [question, setQuestion] = (0, import_react.useState)("");
	const [crumb, setCrumb] = (0, import_react.useState)("");
	const [fortune, setFortune] = (0, import_react.useState)(null);
	const [fortuneSource, setFortuneSource] = (0, import_react.useState)(null);
	const [asking, setAsking] = (0, import_react.useState)(false);
	const [phase, setPhase] = (0, import_react.useState)("idle");
	const [signature, setSignature] = (0, import_react.useState)();
	const [error, setError] = (0, import_react.useState)(null);
	const connected = mounted && wallet.connected && Boolean(wallet.publicKey);
	function onPhase(next, sig) {
		setPhase(next);
		if (sig) setSignature(sig);
	}
	async function afterBake(kind, memo, sig) {
		rememberBake({
			kind,
			memo,
			signature: sig,
			slot: slot ?? 0,
			at: Date.now(),
			address: wallet.publicKey?.toBase58() ?? ""
		});
		await queryClient.invalidateQueries({ queryKey: ["culture"] });
		await queryClient.invalidateQueries({ queryKey: ["cook-balance"] });
		await queryClient.invalidateQueries({ queryKey: ["wallet-txs"] });
		toast.success("Baked on Cookie Chain");
	}
	async function handleAsk() {
		const q = question.trim();
		if (q.length < 3) {
			toast.error("Ask something a little more specific.");
			return;
		}
		setAsking(true);
		setFortune(null);
		setError(null);
		try {
			const res = await askOracle({ data: {
				question: q,
				slot
			} });
			setFortune(res.text);
			setFortuneSource(res.source);
		} catch {
			toast.error("The oracle went quiet. Try again.");
		} finally {
			setAsking(false);
		}
	}
	async function handleBake(memo, kind) {
		if (!connected) {
			toast.error("Connect Nightly on the Cookie network first.");
			return;
		}
		setError(null);
		setSignature(void 0);
		setPhase("signing");
		try {
			await afterBake(kind, memo, (await bakeMemo(wallet, memo, onPhase)).signature);
		} catch (err) {
			const message = err instanceof Error ? err.message : "Bake failed";
			setPhase("error");
			setError(message);
			toast.error(message);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
		className: "scroll-mt-20 p-0",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Bake into the jar" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardDescription, { children: "Fortunes, crumbs, and pulses are SPL memos on Cookie Chain. Fees are a few micro-COOK. Switch Nightly to the Cookie network before you sign." })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tabs, {
				value: tab,
				onValueChange: setTab,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsList, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsTrigger, {
							value: "fortune",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "size-3.5" }), "Fortune"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsTrigger, {
							value: "crumb",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScrollText, { className: "size-3.5" }), "Crumb"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsTrigger, {
							value: "pulse",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Radio, { className: "size-3.5" }), "Pulse"]
						})
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsContent, {
						value: "fortune",
						className: "space-y-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "block text-xs font-medium text-muted",
								htmlFor: "question",
								children: "Ask the oracle"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								id: "question",
								value: question,
								maxLength: 160,
								placeholder: "Will this batch land?",
								onChange: (e) => setQuestion(e.target.value)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-col gap-2 sm:flex-row",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									className: "flex-1",
									variant: "secondary",
									onClick: () => void handleAsk(),
									disabled: asking,
									children: asking ? "Listening…" : "Ask the oracle"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									className: "flex-1",
									onClick: () => fortune && void handleBake(encodeJarMemo("fortune", question, fortune), "fortune"),
									disabled: !fortune || phase === "signing" || phase === "sent" || phase === "confirming",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Flame, { className: "size-4" }), "Bake fortune"]
								})]
							}),
							fortune ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("blockquote", {
								className: "rounded-lg bg-bg px-4 py-3 text-sm leading-relaxed text-fg",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-display text-base leading-snug",
									children: fortune
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-xs text-subtle",
									children: fortuneSource === "oracle" ? "Spoken by the oracle" : "Drawn from the jar"
								})]
							}) : null
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsContent, {
						value: "crumb",
						className: "space-y-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "block text-xs font-medium text-muted",
								htmlFor: "crumb",
								children: "Leave a crumb"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
								id: "crumb",
								value: crumb,
								maxLength: 240,
								placeholder: "GM from the kitchen.",
								onChange: (e) => setCrumb(e.target.value)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between text-xs text-subtle",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
									crumb.trim().length,
									"/",
									240
								] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									onClick: () => void handleBake(encodeJarMemo("crumb", crumb), "crumb"),
									disabled: crumb.trim().length < 2 || phase === "signing" || phase === "sent" || phase === "confirming",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Flame, { className: "size-4" }), "Bake crumb"]
								})]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsContent, {
						value: "pulse",
						className: "space-y-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm leading-normal text-muted text-pretty",
							children: "A pulse is a 1-lamport self-transfer plus a memo. It proves you were here, at this slot, on this chain."
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							className: "w-full",
							onClick: () => void handleBake(encodeJarMemo("pulse"), "pulse"),
							disabled: phase === "signing" || phase === "sent" || phase === "confirming",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Radio, { className: "size-4" }), "Send on-chain pulse"]
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TxStatus, {
				phase,
				signature,
				error
			}),
			!connected ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-4 text-xs leading-normal text-subtle text-pretty",
				children: [
					"Need COOK for fees?",
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						className: "text-muted underline-offset-2 hover:text-fg hover:underline",
						href: LINKS.bridge,
						target: "_blank",
						rel: "noreferrer",
						children: "Bridge from Solana"
					}),
					" · ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						className: "text-muted underline-offset-2 hover:text-fg hover:underline",
						href: "/guide",
						children: "Nightly setup"
					})
				]
			}) : null
		] })]
	});
}
function WalletPanel() {
	const mounted = useMounted();
	const { publicKey, connected, wallet } = useWallet();
	const address = mounted && connected ? publicKey?.toBase58() : void 0;
	const balance = useQuery({
		queryKey: ["cook-balance", address],
		queryFn: () => fetchBalance(address),
		enabled: Boolean(address),
		refetchInterval: 12e3
	});
	const holdings = useQuery({
		queryKey: ["holdings", address],
		queryFn: () => fetchHoldings(address),
		enabled: Boolean(address),
		refetchInterval: 3e4
	});
	const txs = useQuery({
		queryKey: ["wallet-txs", address],
		queryFn: () => fetchRecentWalletTxs(address, 6),
		enabled: Boolean(address),
		refetchInterval: 12e3
	});
	if (!address) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Wallet" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardDescription, { children: "Connect Nightly to read your COOK balance, DAS holdings, and recent signatures. Reads are free; nothing is signed until you bake." })] }) });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Wallet" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardDescription, { children: [
		wallet?.adapter.name ?? "Connected",
		" ·",
		" ",
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
			className: "font-mono text-muted hover:text-fg",
			href: explorerAccount(address),
			target: "_blank",
			rel: "noreferrer",
			children: shortAddress(address, 6)
		})
	] })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
		className: "space-y-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[0.6875rem] font-medium uppercase tracking-wide text-subtle",
				children: "COOK"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 font-mono text-2xl tabular-nums text-fg",
				children: balance.isLoading ? "…" : lamportsToCook(balance.data ?? 0, 6)
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-2 text-[0.6875rem] font-medium uppercase tracking-wide text-subtle",
				children: "Holdings via Cookie DAS"
			}), holdings.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-12" }) : holdings.data && holdings.data.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "space-y-1.5",
				children: holdings.data.slice(0, 8).map((h) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex items-center justify-between gap-3 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "truncate text-fg",
						children: h.symbol
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-mono tabular-nums text-muted",
						children: h.uiAmount.toLocaleString(void 0, { maximumFractionDigits: 4 })
					})]
				}, h.mint))
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "No SPL tokens indexed for this wallet yet."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-2 text-[0.6875rem] font-medium uppercase tracking-wide text-subtle",
				children: "Recent signatures"
			}), txs.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-16" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "divide-y divide-border",
				children: (txs.data ?? []).map((tx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex items-center justify-between gap-3 py-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "truncate font-mono text-xs text-fg",
							children: shortAddress(tx.signature, 8)
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-[0.6875rem] text-subtle",
							children: [formatAgo(tx.blockTime), tx.classified.fromJar ? ` · ${tx.classified.title}` : ""]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: explorerTx(tx.signature),
						target: "_blank",
						rel: "noreferrer",
						className: "inline-flex size-9 items-center justify-center rounded-md text-muted hover:bg-surface-2 hover:text-fg",
						"aria-label": "Open transaction",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, { className: "size-4" })
					})]
				}, tx.signature))
			})] })
		]
	})] });
}
function Home() {
	const net = useQuery({
		queryKey: ["network"],
		queryFn: fetchNetworkSnapshot,
		refetchInterval: 5e3
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto max-w-6xl px-4 py-10 sm:py-14",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "max-w-2xl",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium uppercase tracking-[0.18em] text-muted",
						children: "Cookie Chain cApp"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-3 font-display text-3xl font-medium leading-tight tracking-tight",
						children: "The chain remembers what you bake."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 max-w-xl text-base leading-relaxed text-muted",
						children: "Ask the oracle. Inscribe the answer as an SPL memo. Watch Cookie Chain culture land in sub-second slots — burns, agents, arenas, and this jar."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-6 flex flex-wrap gap-x-5 gap-y-2 text-sm text-subtle",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								className: "hover:text-fg",
								href: LINKS.bridge,
								target: "_blank",
								rel: "noreferrer",
								children: "Bridge COOK"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								className: "hover:text-fg",
								href: LINKS.gettingStarted,
								target: "_blank",
								rel: "noreferrer",
								children: "Docs"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								className: "hover:text-fg",
								href: "/guide",
								children: "Nightly guide"
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-10 grid items-start gap-6 lg:grid-cols-[minmax(0,1.15fr)_minmax(0,0.85fr)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(OvenPanel, { slot: net.data?.slot }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChainDashboard, {})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 grid items-start gap-6 lg:grid-cols-[minmax(0,1.15fr)_minmax(0,0.85fr)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CultureRadar, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WalletPanel, {})]
			})
		]
	}) });
}
//#endregion
export { Home as component };
