//#region node_modules/.nitro/vite/services/ssr/assets/constants-Qd1CV9hU.js
var COOKIE_RPC = "https://rpc.cookiescan.io";
var COOKIE_DAS = "https://api.cookiescan.io";
var GENESIS_HASH = "9wDaBRDgArEUpvhHxGguNkwozsZh4UpGZB9o2EoEcBB2";
var MEMO_PROGRAM_ID = "MemoSq4gqABAXKb96qnH8TysNcWxMyWCqXgDLGmfcHr";
var LAMPORTS_PER_COOK = 1e9;
var AVG_FEE_COOK = 5e-6;
var JAR_PREFIX = "jar:v1";
var LINKS = {
	nightly: "https://nightly.app/download",
	nightlyDocs: "https://nightly.app/docs/solana/solana/detection",
	bridge: "https://hyperlane.cookiescan.io",
	bridgeAlt: "https://bridge.cookiechain.wtf",
	onboard: "https://onboard.cookiechain.wtf",
	docs: "https://docs.cookiechain.wtf",
	gettingStarted: "https://docs.cookiechain.wtf/getting-started",
	explorer: "https://cookiescan.io",
	homepage: "https://www.cookiechain.wtf",
	swap: "https://cookieswap.io",
	cookiebox: "https://cookiebox.app",
	das: "https://api.cookiescan.io",
	telegram: "https://t.me/TheCookieNetChain",
	discord: "https://discord.gg/XqnStmWgNu",
	x: "https://x.com/TheCookieChain"
};
function explorerTx(signature) {
	return `https://cookiescan.io/tx/${signature}`;
}
function explorerAccount(address) {
	return `https://cookiescan.io/account/${address}`;
}
var LOCAL_FORTUNES = [
	"The oven is already hot. You arrived in time for the second batch, not the first.",
	"A wallet that waits for permission never tastes the crumb.",
	"Sub-second finality is a temperament. Act like it.",
	"The jar keeps what you throw. Throw something you can live with.",
	"Cheap fees are not an excuse for empty memos.",
	"Tonight the slot is generous. Tomorrow it will not remember your hesitation.",
	"You are not late. You are under-baked.",
	"Community chains reward the ones who sign, not the ones who spectate.",
	"A pulse is a promise that you were here. Make it count.",
	"The crumb you withhold will be baked by someone louder.",
	"If the bridge feels like a leap, that is because it is. Leap.",
	"Validators do not applaud. They attest. Be worth attesting.",
	"Your next transaction is the smallest brave thing you can do today.",
	"Fortune favors the wallet that can pay a five-micro COOK fee.",
	"The chain is a kitchen. Stop eating and start cooking.",
	"Silence on-chain is still a choice. A worse one.",
	"What you inscribe outlives the tab you close.",
	"The jar does not judge. It only stores heat.",
	"A memo is a whisper with a signature. Whisper carefully.",
	"Let him cook — then take a number and cook anyway."
];
//#endregion
export { JAR_PREFIX as a, LOCAL_FORTUNES as c, explorerTx as d, GENESIS_HASH as i, MEMO_PROGRAM_ID as l, COOKIE_DAS as n, LAMPORTS_PER_COOK as o, COOKIE_RPC as r, LINKS as s, AVG_FEE_COOK as t, explorerAccount as u };
