//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-NbDZR1Y-.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/", "/guide"],
		preloads: ["/assets/index-BoT7HGhL.js", "/assets/constants-rxJbq0jS.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BoT7HGhL.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-Bny1X9YV.js", "/assets/card-lW88FC7b.js"]
	},
	"/guide": {
		filePath: "/workspace/src/routes/guide.tsx",
		children: void 0,
		preloads: ["/assets/guide-CCBTKy_F.js", "/assets/card-lW88FC7b.js"]
	}
} });
//#endregion
export { tsrStartManifest };
